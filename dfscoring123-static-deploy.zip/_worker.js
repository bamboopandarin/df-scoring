/**
 * DF Scoring PRO - Full Cloudflare Pages Advanced Mode Worker (_worker.js)
 * Supports Fast Bootstrap (/api/bootstrap), Auth & Role Management (/api/auth/login, /api/users),
 * Admin Analytics & Recalculation (/api/admin/*), Courts, Matches, Tournaments, Players & Google Sheets Sync.
 * Uses Cloudflare D1 for shared state, with a one-time import from legacy KV.
 */

/**
 * Tournament Engine for Padel & Tennis Master
 * Generates single-elimination brackets with visual tree, round-robin schedules,
 * supports both Singles and Doubles (2 players per team / 4 players per match),
 * automatic match progression, standings table, and champion crowns.
 */

class TournamentManager {
  constructor() {
    this.currentTournament = null;
  }

  // Generate single elimination bracket matches
  static createKnockoutTournament(name, sport, mode, participants, rules) {
    // participants is array of { id, name, photo_url, players?: [] }
    const count = participants.length;
    const bracketSize = 2 ** Math.ceil(Math.log2(count));
    const firstRoundSize = bracketSize / 2;

    // Number of rounds
    const totalRounds = Math.log2(bracketSize);
    const rounds = [];

    // Round 1
    const round1Matches = [];
    for (let i = 0; i < bracketSize / 2; i++) {
      const p1 = participants[i];
      const p2 = participants[i + firstRoundSize] || {
        id: 'BYE_' + i, name: 'BYE (Lolos Otomatis)', is_bye: true, players: []
      };

      const matchId = `r1_m${i + 1}`;
      const isByeMatch = p2.is_bye;

      round1Matches.push({
        id: matchId,
        round: 1,
        match_number: i + 1,
        team_a: p1,
        team_b: p2,
        winner: isByeMatch ? 'team_a' : null,
        winner_participant: isByeMatch ? p1 : null,
        status: isByeMatch ? 'completed' : 'pending',
        sets_history: isByeMatch ? [{ team_a: 'W', team_b: 'BYE' }] : [],
        score_display: isByeMatch ? 'BYE' : 'vs'
      });
    }
    rounds.push({ round_number: 1, name: this.getRoundName(1, totalRounds), matches: round1Matches });

    // Subsequent rounds
    for (let r = 2; r <= totalRounds; r++) {
      const matchesInRound = Math.pow(2, totalRounds - r);
      const roundMatches = [];
      const prevRound = rounds[r - 2];

      for (let m = 0; m < matchesInRound; m++) {
        // Feed from prev round m*2 and m*2+1
        const prevM1 = prevRound.matches[m * 2];
        const prevM2 = prevRound.matches[m * 2 + 1];

        const p1 = prevM1.winner_participant || null;
        const p2 = prevM2.winner_participant || null;

        roundMatches.push({
          id: `r${r}_m${m + 1}`,
          round: r,
          match_number: m + 1,
          team_a: p1,
          team_b: p2,
          winner: null,
          winner_participant: null,
          status: 'pending',
          sets_history: [],
          score_display: 'vs',
          feeds_from: [prevM1.id, prevM2.id]
        });
      }
      rounds.push({ round_number: r, name: this.getRoundName(r, totalRounds), matches: roundMatches });
    }

    return {
      id: 'tourn_' + Math.random().toString(36).substring(2, 9),
      name: name,
      sport: sport,
      mode: mode,
      format: 'knockout',
      total_rounds: totalRounds,
      bracket_size: bracketSize,
      participants: participants,
      rules: rules,
      rounds: rounds,
      status: 'active',
      champion: null,
      champion_name: null,
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };
  }

  // Round Robin generator
  static createRoundRobinTournament(name, sport, mode, participants, rules) {
    let teams = [...participants];
    if (teams.length % 2 !== 0) {
      teams.push({ id: 'BYE', name: 'BYE', is_bye: true, players: [] });
    }

    const n = teams.length;
    const totalRounds = n - 1;
    const matchesPerRound = n / 2;
    const rounds = [];

    // Circle algorithm
    for (let r = 0; r < totalRounds; r++) {
      const roundMatches = [];
      for (let m = 0; m < matchesPerRound; m++) {
        const t1 = teams[m];
        const t2 = teams[n - 1 - m];

        if (!t1.is_bye && !t2.is_bye) {
          roundMatches.push({
            id: `rr_r${r + 1}_m${m + 1}`,
            round: r + 1,
            match_number: m + 1,
            team_a: t1,
            team_b: t2,
            winner: null,
            winner_participant: null,
            status: 'pending',
            sets_history: [],
            score_display: 'vs'
          });
        }
      }
      if (roundMatches.length > 0) {
        rounds.push({ round_number: r + 1, name: `Pekan / Putaran ${r + 1}`, matches: roundMatches });
      }

      // Rotate teams except first
      teams = [teams[0], teams[n - 1], ...teams.slice(1, n - 1)];
    }

    return {
      id: 'tourn_' + Math.random().toString(36).substring(2, 9),
      name: name,
      sport: sport,
      mode: mode,
      format: 'round_robin',
      participants: participants,
      rules: rules,
      rounds: rounds,
      status: 'active',
      champion: null,
      champion_name: null,
      created_at: new Date().toISOString().replace('T', ' ').substring(0, 19)
    };
  }

  static getRoundName(round, totalRounds) {
    const diff = totalRounds - round;
    if (diff === 0) return '🏆 Final';
    if (diff === 1) return 'Semi Final';
    if (diff === 2) return 'Perempat Final (Quarter)';
    if (diff === 3) return 'Babak 16 Besar';
    return `Babak ${round}`;
  }

  // Update tournament match result & advance winner
  static recordMatchResult(tournament, matchId, matchData) {
    let matchFound = null;
    let matchRound = 0;

    for (const round of tournament.rounds) {
      for (const m of round.matches) {
        if (m.id === matchId) {
          matchFound = m;
          matchRound = round.round_number;
          break;
        }
      }
      if (matchFound) break;
    }

    if (!this.isPlayable(matchFound)) return false;

    matchFound.status = 'completed';
    matchFound.winner = matchData.winner; // 'team_a' or 'team_b'
    matchFound.winner_participant = matchData.winner === 'team_a' ? matchFound.team_a : matchFound.team_b;
    matchFound.sets_history = matchData.sets_history || [];
    matchFound.win_type = matchData.win_type || null;
    matchFound.win_reason = matchData.win_reason || '';

    // If won by disqualification or walkover, show clear note
    if (matchData.win_type && matchData.win_type !== "normal") {
      matchFound.score_display = matchData.win_reason || (matchData.win_type === 'disqualification' ? 'W.O. (Diskualifikasi)' : 'W.O.');
    } else if (matchData.sets_history && matchData.sets_history.length > 0) {
      matchFound.score_display = matchData.sets_history.map(s => `${s.team_a}-${s.team_b}`).join(', ');
    } else {
      matchFound.score_display = 'Selesai';
    }

    // If knockout, advance to next round
    if (tournament.format === 'knockout') {
      const nextRoundNum = matchRound + 1;
      const nextRound = tournament.rounds.find(r => r.round_number === nextRoundNum);

      if (nextRound) {
        const nextMatchIndex = Math.floor((matchFound.match_number - 1) / 2);
        const slot = (matchFound.match_number - 1) % 2 === 0 ? 'team_a' : 'team_b';
        if (nextRound.matches[nextMatchIndex]) {
          nextRound.matches[nextMatchIndex][slot] = matchFound.winner_participant;
        }
      } else {
        // This was the final!
        tournament.champion = matchFound.winner_participant;
        tournament.champion_name = matchFound.winner_participant?.name || 'Juara';
        tournament.status = 'completed';
      }
    } else if (tournament.rounds.every(round => round.matches.every(match => match.status === 'completed'))) {
      tournament.champion = this.calculateStandings(tournament)[0]?.participant || null;
      tournament.champion_name = tournament.champion?.name || null;
      tournament.status = 'completed';
    }

    return true;
  }

  static normalize(tournament) {
    if (Array.isArray(tournament.rounds)) return tournament;
    const rounds = tournament.bracket?.rounds || [{ round_number: 1, matches: tournament.schedule || [] }];
    return {
      ...tournament,
      rounds: rounds.map((round, index) => ({
        ...round,
        round_number: round.round_number || index + 1,
        matches: round.matches.map(match => ({
          ...match,
          team_a: match.team_a || match.player_a,
          team_b: match.team_b || match.player_b,
          winner: typeof match.winner === 'object' && match.winner
            ? (match.winner.id === (match.team_a || match.player_a)?.id ? 'team_a' : 'team_b')
            : match.winner,
          score_display: match.score_display || match.score_summary || 'vs'
        }))
      }))
    };
  }

  static findMatch(tournament, id) {
    return tournament?.rounds.flatMap(round => round.matches).find(match => match.id === id);
  }

  static isPlayable(match) {
    return Boolean(match?.team_a && match.team_b && !match.team_a.is_bye && !match.team_b.is_bye
      && match.status !== 'completed');
  }

  static hasResults(tournament) {
    return this.normalize(tournament).rounds.some(round => round.matches.some(match =>
      match.status === 'completed' && !match.team_a?.is_bye && !match.team_b?.is_bye));
  }

  // Record direct Walkover / Disqualification from bracket without starting match
  static recordWalkover(tournament, matchId, winnerTeamSlot, reasonType, customNote = '') {
    let matchFound = null;
    let matchRound = 0;

    for (const round of tournament.rounds) {
      for (const m of round.matches) {
        if (m.id === matchId) {
          matchFound = m;
          matchRound = round.round_number;
          break;
        }
      }
      if (matchFound) break;
    }

    if (!matchFound) return false;

    let reasonStr = customNote;
    if (!reasonStr) {
      if (reasonType === 'disqualification') reasonStr = 'W.O. (Diskualifikasi)';
      else if (reasonType === 'retired') reasonStr = 'Mundur / Cedera (RET)';
      else reasonStr = 'W.O. (Tidak Hadir)';
    }

    const winnerParticipant = winnerTeamSlot === 'team_a' ? matchFound.team_a : matchFound.team_b;
    const loserParticipant = winnerTeamSlot === 'team_a' ? matchFound.team_b : matchFound.team_a;

    const matchData = {
      winner: winnerTeamSlot,
      winner_participant: winnerParticipant,
      win_type: reasonType,
      win_reason: reasonStr,
      sets_history: [
        {
          team_a: winnerTeamSlot === 'team_a' ? 'W' : 'Gugur',
          team_b: winnerTeamSlot === 'team_b' ? 'W' : 'Gugur',
          winner: winnerTeamSlot,
          note: reasonStr
        }
      ]
    };

    return this.recordMatchResult(tournament, matchId, matchData);
  }

  // Swap first-round slots, then propagate automatic BYE results again.
  static swapRound1Participants(tournament, matchIdx1, slot1, matchIdx2, slot2) {
    if (this.hasResults(tournament)) {
      return { success: false, message: 'Bagan sudah memiliki hasil pertandingan.' };
    }
    const [firstRound, nextRound] = tournament.rounds;
    const m1 = firstRound.matches[matchIdx1];
    const m2 = firstRound.matches[matchIdx2];
    if (!m1?.[slot1] || !m2?.[slot2]) return { success: false, message: 'Slot tidak tersedia.' };

    [m1[slot1], m2[slot2]] = [m2[slot2], m1[slot1]];
    if ([m1, m2].some(match => match.team_a.is_bye && match.team_b.is_bye)) {
      [m1[slot1], m2[slot2]] = [m2[slot2], m1[slot1]];
      return { success: false, message: 'Satu pertandingan harus memiliki minimal satu peserta.' };
    }

    firstRound.matches.forEach((match, index) => {
      match.winner = match.team_a.is_bye ? 'team_b' : match.team_b.is_bye ? 'team_a' : null;
      match.winner_participant = match.winner ? match[match.winner] : null;
      match.status = match.winner ? 'completed' : 'pending';
      match.score_display = match.winner ? 'BYE' : 'vs';
      match.sets_history = [];
      if (nextRound) {
        const slot = index % 2 === 0 ? 'team_a' : 'team_b';
        nextRound.matches[Math.floor(index / 2)][slot] = match.winner_participant;
      }
    });
    return { success: true };
  }

  // Calculate Round Robin Standings
  static calculateStandings(tournament) {
    if (tournament.format !== 'round_robin') return [];

    const statsMap = Object.create(null);
    tournament.participants.forEach(p => {
      statsMap[p.id] = {
        participant: p,
        played: 0,
        won: 0,
        lost: 0,
        sets_won: 0,
        sets_lost: 0,
        games_won: 0,
        games_lost: 0,
        points: 0
      };
    });

    for (const round of tournament.rounds) {
      for (const m of round.matches) {
        if (m.status === 'completed' && m.sets_history) {
          const aId = m.team_a?.id;
          const bId = m.team_b?.id;
          if (!aId || !bId || !statsMap[aId] || !statsMap[bId]) continue;

          statsMap[aId].played++;
          statsMap[bId].played++;

          let setsA = 0;
          let setsB = 0;
          let gamesA = 0;
          let gamesB = 0;

          m.sets_history.forEach(s => {
            const gA = parseInt(s.team_a) || 0;
            const gB = parseInt(s.team_b) || 0;
            gamesA += gA;
            gamesB += gB;
            if (s.partial) return;
            if (s.winner === 'team_a' || gA > gB) setsA++;
            else if (s.winner === 'team_b' || gB > gA) setsB++;
          });

          statsMap[aId].sets_won += setsA;
          statsMap[aId].sets_lost += setsB;
          statsMap[bId].sets_won += setsB;
          statsMap[bId].sets_lost += setsA;

          statsMap[aId].games_won += gamesA;
          statsMap[aId].games_lost += gamesB;
          statsMap[bId].games_won += gamesB;
          statsMap[bId].games_lost += gamesA;

          if (m.winner === 'team_a') {
            statsMap[aId].won++;
            statsMap[aId].points += 3;
            statsMap[bId].lost++;
          } else if (m.winner === 'team_b') {
            statsMap[bId].won++;
            statsMap[bId].points += 3;
            statsMap[aId].lost++;
          }
        }
      }
    }

    const standings = Object.values(statsMap);
    standings.sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      const setDiffB = b.sets_won - b.sets_lost;
      const setDiffA = a.sets_won - a.sets_lost;
      if (setDiffB !== setDiffA) return setDiffB - setDiffA;
      const gameDiffB = b.games_won - b.games_lost;
      const gameDiffA = a.games_won - a.games_lost;
      return gameDiffB - gameDiffA;
    });

    return standings;
  }
}

if (typeof window !== "undefined") window.TournamentManager = TournamentManager;


/**
 * Tennis & Padel Rules & Scoring Engine PRO
 * Supports standard tennis (Deuce & Advantage), padel golden-point (punto de oro),
 * doubles (4 players with rotating service), mini-games (1 to 10+ games),
 * tiebreaks, super tiebreak, full undo/redo, rich point-by-point statistics,
 * lossless JSON serialization (toJSON / toLightJSON / fromJSON), and side change alerts.
 */

class MatchScorer {
  constructor(config = {}) {
    this.init(config);
  }

  init(config = {}) {
    this.sport = config.sport || 'padel'; // 'padel' or 'tennis'
    this.mode = config.mode || 'doubles'; // 'singles' or 'doubles'
    this.id = config.id || ('m_' + Math.random().toString(36).substring(2, 10));
    this.tournament_id = config.tournament_id || null;
    this.tournament_match_id = config.tournament_match_id || null;
    this.tournament_name = config.tournament_name || '';
    this.version = config.version || 1;
    this.scored_by = config.scored_by || null; // { name, email, role }

    const teamAObj = config.team_a || {};
    const teamBObj = config.team_b || {};

    // Team A
    this.team_a = {
      name: config.team_a_name || teamAObj.name || 'Tim A',
      players: config.team_a_players || teamAObj.players || [],
      photo: config.team_a_photo || teamAObj.photo || ''
    };

    // Team B
    this.team_b = {
      name: config.team_b_name || teamBObj.name || 'Tim B',
      players: config.team_b_players || teamBObj.players || [],
      photo: config.team_b_photo || teamBObj.photo || ''
    };

    // Ensure players array has 2 slots in doubles mode
    if (this.mode === 'doubles') {
      if (!this.team_a.players || this.team_a.players.length === 0) {
        this.team_a.players = [
          { name: 'Pemain A1', photo_url: '' },
          { name: 'Pemain A2', photo_url: '' }
        ];
      }
      if (!this.team_b.players || this.team_b.players.length === 0) {
        this.team_b.players = [
          { name: 'Pemain B1', photo_url: '' },
          { name: 'Pemain B2', photo_url: '' }
        ];
      }
    } else {
      if (!this.team_a.players || this.team_a.players.length === 0) {
        this.team_a.players = [{ name: this.team_a.name, photo_url: this.team_a.photo || '' }];
      }
      if (!this.team_b.players || this.team_b.players.length === 0) {
        this.team_b.players = [{ name: this.team_b.name, photo_url: this.team_b.photo || '' }];
      }
    }

    const defaultGames = config.rules?.games_per_set ?? 6;

    this.rules = {
      sets_to_win: config.rules?.sets_to_win ?? 2,
      games_per_set: defaultGames,
      golden_point: config.rules?.golden_point ?? false,
      tiebreak_at: config.rules?.tiebreak_at ?? defaultGames,
      tiebreak_points: config.rules?.tiebreak_points ?? 7,
      final_set_super_tiebreak: config.rules?.final_set_super_tiebreak ?? false
    };

    // Live match state
    this.sets_history = Array.isArray(config.sets_history) ? JSON.parse(JSON.stringify(config.sets_history)) : [];
    this.current_set_games = config.current_set_games ? { ...config.current_set_games } : { team_a: 0, team_b: 0 };
    this.current_points = config.current_points ? { ...config.current_points } : { team_a: 0, team_b: 0 };
    this.tiebreak_points = config.tiebreak_points ? { ...config.tiebreak_points } : { team_a: 0, team_b: 0 };

    this.is_tiebreak = !!config.is_tiebreak;
    this.is_super_tiebreak = !!config.is_super_tiebreak;

    // Server tracking: team and individual player index for doubles
    this.server = config.server || config.initial_server || 'team_a';
    this.server_start_of_game = config.server_start_of_game || this.server;
    this.server_player_index = config.server_player_index
      ? { ...config.server_player_index }
      : { team_a: 0, team_b: 0 };

    this.winner = config.winner || null;
    this.is_completed = !!(config.is_completed || config.status === 'completed');
    this.win_type = config.win_type || null; // 'walkover' | 'disqualification' | 'retired'
    this.win_reason = config.win_reason || '';
    this.court_id = config.court_id || 'court_1';
    this.start_time = config.start_time ? new Date(config.start_time) : new Date();
    this.end_time = config.end_time ? new Date(config.end_time) : null;
    this.duration_minutes = config.duration_minutes || 0;
    this.duration_seconds = config.duration_seconds || 0;

    // Detailed Match Analytics
    this.stats = config.stats ? { ...config.stats } : {
      total_points_a: 0,
      total_points_b: 0,
      deuces_count: 0,
      golden_points_count: 0,
      service_games_won_a: 0,
      service_games_won_b: 0,
      breaks_won_a: 0,
      breaks_won_b: 0,
      max_streak_a: 0,
      max_streak_b: 0,
      current_streak_a: 0,
      current_streak_b: 0
    };

    this.point_log = Array.isArray(config.point_log) ? [...config.point_log] : [];

    // History stack for Undo/Redo
    this.undo_count = config.undo_count || 0;
    this.redo_count = config.redo_count || 0;
    this.history = config.history || [];
    this.redoStack = config.redoStack || [];

    // Notifications
    this.side_switch_alert = !!config.side_switch_alert;
  }

  static fromJSON(data = {}) {
    if (!data || typeof data !== 'object') {
      return new MatchScorer();
    }
    return new MatchScorer(data);
  }

  // Clone current snapshot for Undo/Redo
  getSnapshot() {
    return {
      sets_history: JSON.parse(JSON.stringify(this.sets_history)),
      current_set_games: { ...this.current_set_games },
      current_points: { ...this.current_points },
      tiebreak_points: { ...this.tiebreak_points },
      is_tiebreak: this.is_tiebreak,
      is_super_tiebreak: this.is_super_tiebreak,
      server: this.server,
      server_start_of_game: this.server_start_of_game,
      server_player_index: { ...this.server_player_index },
      rules: { ...this.rules },
      winner: this.winner,
      is_completed: this.is_completed,
      win_type: this.win_type,
      win_reason: this.win_reason,
      court_id: this.court_id,
      start_time: this.start_time.toISOString(),
      end_time: this.end_time?.toISOString() || null,
      side_switch_alert: this.side_switch_alert,
      stats: { ...this.stats },
      point_log: JSON.parse(JSON.stringify(this.point_log))
    };
  }

  restoreSnapshot(snap) {
    this.sets_history = JSON.parse(JSON.stringify(snap.sets_history));
    this.current_set_games = { ...snap.current_set_games };
    this.current_points = { ...snap.current_points };
    this.tiebreak_points = { ...snap.tiebreak_points };
    this.is_tiebreak = snap.is_tiebreak;
    this.is_super_tiebreak = snap.is_super_tiebreak;
    this.server = snap.server;
    this.server_start_of_game = snap.server_start_of_game;
    this.server_player_index = { ...(snap.server_player_index || { team_a: 0, team_b: 0 }) };
    if (snap.rules) this.rules = { ...snap.rules };
    this.winner = snap.winner;
    this.is_completed = snap.is_completed;
    this.win_type = snap.win_type || null;
    this.win_reason = snap.win_reason || '';
    this.court_id = snap.court_id || 'court_1';
    if (snap.start_time) this.start_time = new Date(snap.start_time);
    this.end_time = snap.end_time ? new Date(snap.end_time) : null;
    this.side_switch_alert = snap.side_switch_alert;
    if (snap.stats) this.stats = { ...snap.stats };
    if (snap.point_log) this.point_log = JSON.parse(JSON.stringify(snap.point_log));
    this.version++;
  }

  pushHistory() {
    this.history.push(this.getSnapshot());
    if (this.history.length > 30) this.history.shift();
    this.redoStack = [];
    this.version++;
  }

  undo() {
    if (this.history.length === 0) return false;
    this.redoStack.push(this.getSnapshot());
    const prev = this.history.pop();
    this.restoreSnapshot(prev);
    globalThis.soundEngine?.playUndoBeep();
    return true;
  }

  redo() {
    if (this.redoStack.length === 0) return false;
    this.history.push(this.getSnapshot());
    const next = this.redoStack.pop();
    this.restoreSnapshot(next);
    globalThis.soundEngine?.playPointBeep();
    return true;
  }

  resetMatch() {
    this.pushHistory();
    this.sets_history = [];
    this.current_set_games = { team_a: 0, team_b: 0 };
    this.current_points = { team_a: 0, team_b: 0 };
    this.tiebreak_points = { team_a: 0, team_b: 0 };
    this.is_tiebreak = false;
    this.is_super_tiebreak = false;
    this.winner = null;
    this.is_completed = false;
    this.win_type = null;
    this.win_reason = '';
    this.side_switch_alert = false;
    this.start_time = new Date();
    this.end_time = null;
    this.duration_minutes = 0;
    this.duration_seconds = 0;
    this.stats = {
      total_points_a: 0,
      total_points_b: 0,
      deuces_count: 0,
      golden_points_count: 0,
      service_games_won_a: 0,
      service_games_won_b: 0,
      breaks_won_a: 0,
      breaks_won_b: 0,
      max_streak_a: 0,
      max_streak_b: 0,
      current_streak_a: 0,
      current_streak_b: 0
    };
    this.point_log = [];
  }

  // Toggle serving team or individual server in doubles
  toggleServer() {
    this.pushHistory();
    if (this.mode === 'doubles') {
      if (this.server === 'team_a') {
        this.server = 'team_b';
      } else {
        this.server = 'team_a';
        this.server_player_index.team_a = this.server_player_index.team_a === 0 ? 1 : 0;
        this.server_player_index.team_b = this.server_player_index.team_b === 0 ? 1 : 0;
      }
    } else {
      this.server = this.server === 'team_a' ? 'team_b' : 'team_a';
    }
    this.server_start_of_game = this.server;
  }

  // Set explicit server player in doubles
  setDoublesServer(team, playerIndex) {
    this.pushHistory();
    this.server = team;
    this.server_start_of_game = team;
    this.server_player_index[team] = playerIndex;
  }

  applyAction(action) {
    const { type, team, player, games, reason, note } = action || {};
    if (type === 'undo') return this.undo();
    if (type === 'redo') return this.redo();
    if (this.is_completed) return false;

    const validTeam = team === 'team_a' || team === 'team_b';
    if (type === 'point' && validTeam) this.addPoint(team);
    else if (type === 'server') this.toggleServer();
    else if (type === 'doubles_server' && this.mode === 'doubles' && validTeam && [0, 1].includes(player)) {
      this.setDoublesServer(team, player);
    } else if (type === 'golden_point') this.toggleGoldenPoint();
    else if (type === 'target' && Number.isInteger(games) && games >= 1 && games <= 50) this.setTargetGames(games);
    else if (type === 'reset') this.resetMatch();
    else if (type === 'walkover' && validTeam && ['walkover', 'disqualification', 'retired'].includes(reason)) {
      this.winByDefault(team, reason, String(note || '').slice(0, 200));
    } else return false;
    return true;
  }

  finishEarly(winner) {
    if (winner !== 'team_a' && winner !== 'team_b') return false;
    this.winner = winner;
    this.is_completed = true;
    this.win_reason = 'Diselesaikan manual';
    this.end_time = new Date();
    const { team_a, team_b } = this.current_set_games;
    if (team_a || team_b) this.sets_history.push({ team_a, team_b, partial: true });
    return true;
  }

  // Toggle Golden Point on the fly
  toggleGoldenPoint() {
    this.pushHistory();
    this.rules.golden_point = !this.rules.golden_point;
    if (this.rules.golden_point) {
      if (this.current_points.team_a === 4) this.current_points.team_a = 3;
      if (this.current_points.team_b === 4) this.current_points.team_b = 3;
    }
    return this.rules.golden_point;
  }

  // Update target games per set on the fly (for mini-games)
  setTargetGames(num) {
    const val = parseInt(num) || 6;
    this.pushHistory();
    this.rules.games_per_set = val;
    this.rules.tiebreak_at = val;
  }

  // --- Add Point ---
  addPoint(team) {
    if (this.is_completed) return;
    this.pushHistory();
    this.side_switch_alert = false;

    globalThis.soundEngine?.playPointBeep();

    // Update Point & Streak Analytics
    if (team === 'team_a') {
      this.stats.total_points_a = (this.stats.total_points_a || 0) + 1;
      this.stats.current_streak_a = (this.stats.current_streak_a || 0) + 1;
      this.stats.current_streak_b = 0;
      if (this.stats.current_streak_a > (this.stats.max_streak_a || 0)) {
        this.stats.max_streak_a = this.stats.current_streak_a;
      }
    } else {
      this.stats.total_points_b = (this.stats.total_points_b || 0) + 1;
      this.stats.current_streak_b = (this.stats.current_streak_b || 0) + 1;
      this.stats.current_streak_a = 0;
      if (this.stats.current_streak_b > (this.stats.max_streak_b || 0)) {
        this.stats.max_streak_b = this.stats.current_streak_b;
      }
    }

    const otherTeam = team === 'team_a' ? 'team_b' : 'team_a';

    if (this.is_tiebreak || this.is_super_tiebreak) {
      this.handleTiebreakPoint(team, otherTeam);
    } else {
      this.handleRegularPoint(team, otherTeam);
    }

    // Record to point log (keep last 80 points for timeline analysis)
    this.point_log.push({
      t: new Date().toISOString().substring(11, 19),
      team,
      pt_a: this.getDisplayPoint('team_a'),
      pt_b: this.getDisplayPoint('team_b'),
      gm_a: this.current_set_games.team_a,
      gm_b: this.current_set_games.team_b,
      set_a: this.getSetsWon('team_a'),
      set_b: this.getSetsWon('team_b')
    });
    if (this.point_log.length > 80) {
      this.point_log.shift();
    }
  }

  handleRegularPoint(team, otherTeam) {
    const ptTeam = this.current_points[team];
    const ptOther = this.current_points[otherTeam];

    // 1. Check Golden Point (No-Ad at 40-40)
    if (this.rules.golden_point && ptTeam === 3 && ptOther === 3) {
      this.winGame(team);
      return;
    }

    // 2. Standard Tennis / Advantage scoring
    if (ptTeam === 3 && ptOther < 3) {
      this.winGame(team);
    } else if (ptTeam < 3 && ptOther === 3) {
      this.current_points[team]++;
      if (this.current_points.team_a === 3 && this.current_points.team_b === 3) {
        if (this.rules.golden_point) {
          this.stats.golden_points_count = (this.stats.golden_points_count || 0) + 1;
        } else {
          this.stats.deuces_count = (this.stats.deuces_count || 0) + 1;
        }
      }
      this.announceCurrentScore();
    } else if (ptTeam === 3 && ptOther === 3) {
      // 40-40 (DEUCE) -> Team gains ADVANTAGE (pt = 4)
      this.current_points[team] = 4;
      this.announceCurrentScore();
    } else if (ptTeam === 4) {
      // Advantage -> Game!
      this.winGame(team);
    } else if (ptOther === 4) {
      // Opponent had Advantage -> back to DEUCE (3 - 3)!
      this.current_points[otherTeam] = 3;
      this.stats.deuces_count = (this.stats.deuces_count || 0) + 1;
      this.announceCurrentScore();
    } else {
      // 0->15->30->40
      this.current_points[team]++;
      this.announceCurrentScore();
    }
  }

  handleTiebreakPoint(team, otherTeam) {
    this.tiebreak_points[team]++;
    const target = this.is_super_tiebreak ? 10 : (this.rules.tiebreak_points || 7);
    const scoreA = this.tiebreak_points.team_a;
    const scoreB = this.tiebreak_points.team_b;
    const totalPts = scoreA + scoreB;

    // Service rotation in tiebreak: ABBA
    if (totalPts % 2 === 1) {
      this.server = this.server === 'team_a' ? 'team_b' : 'team_a';
      if (this.mode === 'doubles') {
        this.server_player_index[this.server] = this.server_player_index[this.server] === 0 ? 1 : 0;
      }
    }

    // Side change reminder every 6 points in tiebreak
    if (totalPts % 6 === 0) {
      this.side_switch_alert = true;
      globalThis.soundEngine?.announceSideSwitch();
    }

    const ptsTeam = this.tiebreak_points[team];
    const ptsOther = this.tiebreak_points[otherTeam];

    if (ptsTeam >= target && (ptsTeam - ptsOther) >= 2) {
      this.current_set_games[team]++;
      this.winSet(team, true);
    } else {
      globalThis.soundEngine?.announceScore(
        scoreA,
        scoreB,
        this.server === 'team_a',
        this.team_a.name,
        this.team_b.name,
        true,
        false
      );
    }
  }

  winGame(team) {
    this.current_points = { team_a: 0, team_b: 0 };
    this.current_set_games[team]++;

    // Track service hold vs break of serve
    if (this.server === team) {
      if (team === 'team_a') this.stats.service_games_won_a = (this.stats.service_games_won_a || 0) + 1;
      else this.stats.service_games_won_b = (this.stats.service_games_won_b || 0) + 1;
    } else {
      if (team === 'team_a') this.stats.breaks_won_a = (this.stats.breaks_won_a || 0) + 1;
      else this.stats.breaks_won_b = (this.stats.breaks_won_b || 0) + 1;
    }

    const teamWinnerName = team === 'team_a' ? this.team_a.name : this.team_b.name;
    const gamesA = this.current_set_games.team_a;
    const gamesB = this.current_set_games.team_b;
    const targetGames = this.rules.games_per_set;

    // Rotate regular server for next game
    if (this.mode === 'doubles') {
      if (this.server_start_of_game === 'team_a') {
        this.server_start_of_game = 'team_b';
      } else {
        this.server_start_of_game = 'team_a';
        this.server_player_index.team_a = this.server_player_index.team_a === 0 ? 1 : 0;
        this.server_player_index.team_b = this.server_player_index.team_b === 0 ? 1 : 0;
      }
    } else {
      this.server_start_of_game = this.server_start_of_game === 'team_a' ? 'team_b' : 'team_a';
    }
    this.server = this.server_start_of_game;

    // Side switch reminder: odd number of total games in set (1, 3, 5, 7...)
    const totalGames = gamesA + gamesB;
    if (totalGames % 2 === 1) {
      this.side_switch_alert = true;
    }

    // --- CHECK MINI-GAME OR FULL SET WIN ---
    const gamesWinner = this.current_set_games[team];
    const gamesLoser = this.current_set_games[team === 'team_a' ? 'team_b' : 'team_a'];

    // 1. Mini Game (1 game per set)
    if (targetGames === 1 && gamesWinner >= 1) {
      this.winSet(team, false);
      return;
    }

    // 2. Standard or Custom games per set (lead by 2 when reaching target)
    if (gamesWinner >= targetGames && (gamesWinner - gamesLoser) >= 2) {
      this.winSet(team, false);
      return;
    }

    // 3. Pro set or advantage set reaching target+1 (e.g. 7-5 if target was 6)
    if (gamesWinner === targetGames + 1 && gamesLoser === targetGames - 1) {
      this.winSet(team, false);
      return;
    }

    // 4. Tiebreak trigger: both teams reached tiebreak_at (e.g. 6-6, 3-3, 4-4)
    if (gamesA === this.rules.tiebreak_at && gamesB === this.rules.tiebreak_at) {
      this.is_tiebreak = true;
      this.tiebreak_points = { team_a: 0, team_b: 0 };
      globalThis.soundEngine?.announceGame(teamWinnerName, gamesA, gamesB);
      setTimeout(() => {
        globalThis.soundEngine?.speak(globalThis.soundEngine.voiceLang === 'id-ID' ? 'Memasuki Tie-break!' : 'Entering Tie-break!');
      }, 900);
      return;
    }

    globalThis.soundEngine?.announceGame(teamWinnerName, gamesA, gamesB);
    if (this.side_switch_alert) {
      if (globalThis.soundEngine) setTimeout(() => globalThis.soundEngine.announceSideSwitch(), 950);
    }
  }

  winSet(team, wasTiebreak = false) {
    const winnerName = team === 'team_a' ? this.team_a.name : this.team_b.name;

    const setRecord = {
      team_a: this.current_set_games.team_a,
      team_b: this.current_set_games.team_b,
      tiebreak_a: wasTiebreak ? this.tiebreak_points.team_a : null,
      tiebreak_b: wasTiebreak ? this.tiebreak_points.team_b : null,
      winner: team
    };
    this.sets_history.push(setRecord);

    // Reset games & tiebreak
    this.current_set_games = { team_a: 0, team_b: 0 };
    this.current_points = { team_a: 0, team_b: 0 };
    this.tiebreak_points = { team_a: 0, team_b: 0 };
    this.is_tiebreak = false;

    const setsWonA = this.sets_history.filter(s => s.winner === 'team_a').length;
    const setsWonB = this.sets_history.filter(s => s.winner === 'team_b').length;

    const setsNeeded = this.rules.sets_to_win;
    if (setsWonA >= setsNeeded) {
      this.finishMatch('team_a');
      return;
    } else if (setsWonB >= setsNeeded) {
      this.finishMatch('team_b');
      return;
    }

    const currentSetIndex = this.sets_history.length + 1;
    const totalSetsBestOf = setsNeeded * 2 - 1;
    if (this.rules.final_set_super_tiebreak && currentSetIndex === totalSetsBestOf) {
      this.is_super_tiebreak = true;
      this.is_tiebreak = true;
    }

    globalThis.soundEngine?.announceSet(winnerName, this.sets_history.length, setsWonA, setsWonB);
  }

  finishMatch(winner) {
    this.winner = winner;
    this.is_completed = true;
    this.end_time = new Date();
    this.duration_minutes = Math.max(1, Math.round((this.end_time - this.start_time) / 60000));

    const winnerName = winner === 'team_a' ? this.team_a.name : this.team_b.name;
    globalThis.soundEngine?.announceMatch(winnerName);
  }

  // Win by Walkover (W.O.), Disqualification (DQ), or Retirement (RET)
  winByDefault(winnerTeam, reasonType = 'walkover', customNote = '') {
    this.pushHistory();
    this.winner = winnerTeam;
    this.is_completed = true;
    this.win_type = reasonType;

    let defaultReason = 'Walkover (W.O.)';
    if (reasonType === 'disqualification') defaultReason = 'Diskualifikasi (DQ)';
    else if (reasonType === 'retired') defaultReason = 'Mundur / Cedera (RET)';
    else if (reasonType === 'walkover') defaultReason = 'Tidak Hadir / Walkover (W.O.)';

    this.win_reason = customNote || defaultReason;
    this.end_time = new Date();
    this.duration_minutes = Math.max(1, Math.round((this.end_time - this.start_time) / 60000));

    const winLabel = winnerTeam === 'team_a' ? 'W' : 'Gugur';
    const loseLabel = winnerTeam === 'team_b' ? 'W' : 'Gugur';

    if (this.sets_history.length === 0) {
      this.sets_history.push({
        team_a: winLabel,
        team_b: loseLabel,
        winner: winnerTeam,
        note: this.win_reason
      });
    } else {
      this.sets_history.push({
        team_a: `${this.current_set_games.team_a} (${winLabel})`,
        team_b: `${this.current_set_games.team_b} (${loseLabel})`,
        winner: winnerTeam,
        note: this.win_reason
      });
    }

    const winnerName = winnerTeam === 'team_a' ? this.team_a.name : this.team_b.name;
    globalThis.soundEngine?.announceWalkoverWin(winnerName, this.win_reason);
  }

  announceCurrentScore() {
    const isGold = this.isGoldenPoint();
    globalThis.soundEngine?.announceScore(
      this.getDisplayPoint('team_a'),
      this.getDisplayPoint('team_b'),
      this.server === 'team_a',
      this.team_a.name,
      this.team_b.name,
      this.is_tiebreak || this.is_super_tiebreak,
      isGold
    );
  }

  getDisplayPoint(team) {
    if (this.is_tiebreak || this.is_super_tiebreak) {
      return (this.tiebreak_points[team] || 0).toString();
    }
    const pt = this.current_points[team] || 0;
    if (pt === 0) return '0';
    if (pt === 1) return '15';
    if (pt === 2) return '30';
    if (pt === 3) return '40';
    if (pt === 4) return 'AD';
    return '0';
  }

  isGoldenPoint() {
    return this.rules.golden_point &&
      !this.is_tiebreak &&
      this.current_points.team_a === 3 &&
      this.current_points.team_b === 3;
  }

  isDeuce() {
    return !this.rules.golden_point &&
      !this.is_tiebreak &&
      this.current_points.team_a === 3 &&
      this.current_points.team_b === 3;
  }

  hasAdvantage() {
    return !this.rules.golden_point &&
      !this.is_tiebreak &&
      (this.current_points.team_a === 4 || this.current_points.team_b === 4);
  }

  getAdvantageTeam() {
    if (this.current_points.team_a === 4) return 'team_a';
    if (this.current_points.team_b === 4) return 'team_b';
    return null;
  }

  getSetsWon(team) {
    return this.sets_history.filter(s => s.winner === team).length;
  }

  getActiveServerPlayer() {
    const team = this.server;
    const teamObj = team === 'team_a' ? this.team_a : this.team_b;
    if (this.mode === 'doubles' && teamObj.players && teamObj.players.length > 0) {
      const idx = (this.server_player_index[team] || 0) % teamObj.players.length;
      return teamObj.players[idx];
    }
    return teamObj.players?.[0] || { name: teamObj.name };
  }

  toJSON() {
    const setsWonA = this.getSetsWon('team_a');
    const setsWonB = this.getSetsWon('team_b');
    return {
      id: this.id,
      version: this.version,
      tournament_id: this.tournament_id,
      tournament_match_id: this.tournament_match_id,
      tournament_name: this.tournament_name,
      court_id: this.court_id || 'court_1',
      date: this.start_time.toISOString().replace('T', ' ').substring(0, 19),
      start_time: this.start_time.toISOString(),
      end_time: this.end_time?.toISOString() || null,
      updated_at_ms: Date.now(),
      name: `${this.team_a.name} vs ${this.team_b.name}`,
      sport: this.sport,
      mode: this.mode,
      team_a_name: this.team_a.name,
      team_b_name: this.team_b.name,
      team_a_photo: this.team_a.photo || '',
      team_b_photo: this.team_b.photo || '',
      team_a: this.team_a,
      team_b: this.team_b,
      team_a_player_ids: (this.team_a.players || []).map(p => p.id || p.name || 'player_a'),
      team_b_player_ids: (this.team_b.players || []).map(p => p.id || p.name || 'player_b'),
      team_a_players: this.team_a.players || [],
      team_b_players: this.team_b.players || [],
      rules: { ...this.rules },
      sets_history: this.sets_history,
      current_set_games: { ...this.current_set_games },
      current_points: { ...this.current_points },
      tiebreak_points: { ...this.tiebreak_points },
      is_tiebreak: this.is_tiebreak,
      is_super_tiebreak: this.is_super_tiebreak,
      server: this.server,
      server_start_of_game: this.server_start_of_game,
      server_player_index: { ...this.server_player_index },
      sets_won: { team_a: setsWonA, team_b: setsWonB },
      display_point_a: this.getDisplayPoint('team_a'),
      display_point_b: this.getDisplayPoint('team_b'),
      side_switch_alert: this.side_switch_alert,
      stats: { ...this.stats },
      point_log: this.point_log,
      scored_by: this.scored_by,
      winner: this.winner,
      is_completed: this.is_completed,
      win_type: this.win_type || null,
      win_reason: this.win_reason || '',
      status: this.is_completed ? 'completed' : 'in_progress',
      duration_minutes: this.duration_minutes || Math.max(1, Math.round((this.duration_seconds || 0) / 60)),
      duration_seconds: this.duration_seconds || 0
    };
  }

  // Lightweight JSON payload for real-time court sync (strips heavy base64 audio/images)
  toLightJSON() {
    const full = this.toJSON();
    const stripHeavy = (p) => {
      if (!p) return p;
      const copy = { ...p };
      if (copy.slogan_audio_url && copy.slogan_audio_url.startsWith('data:')) {
        copy.slogan_audio_url = '';
      }
      if (copy.photo_url && copy.photo_url.length > 4000) {
        copy.photo_url = '';
      }
      return copy;
    };
    full.team_a_players = (full.team_a_players || []).map(stripHeavy);
    full.team_b_players = (full.team_b_players || []).map(stripHeavy);
    if (full.team_a && full.team_a.players) {
      full.team_a = { ...full.team_a, players: full.team_a.players.map(stripHeavy) };
    }
    if (full.team_b && full.team_b.players) {
      full.team_b = { ...full.team_b, players: full.team_b.players.map(stripHeavy) };
    }
    if (full.team_a_photo && full.team_a_photo.length > 4000) full.team_a_photo = '';
    if (full.team_b_photo && full.team_b_photo.length > 4000) full.team_b_photo = '';
    return full;
  }
}

if (typeof window !== "undefined") window.MatchScorer = MatchScorer;


const DB_SCHEMA = [
  "CREATE TABLE IF NOT EXISTS df_revision (id INTEGER PRIMARY KEY CHECK (id = 1), revision INTEGER NOT NULL CHECK (revision >= 0), data_revision INTEGER NOT NULL)",
  "INSERT OR IGNORE INTO df_revision VALUES (1, 0, 0)",
  "CREATE TABLE IF NOT EXISTS df_state (key TEXT NOT NULL, part INTEGER NOT NULL, value TEXT NOT NULL, PRIMARY KEY (key, part))",
  "CREATE TABLE IF NOT EXISTS df_accounts (login TEXT PRIMARY KEY, user_id TEXT NOT NULL UNIQUE, name TEXT NOT NULL, email TEXT NOT NULL, salt TEXT, password_hash TEXT)",
  "CREATE TABLE IF NOT EXISTS df_sessions (digest TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires INTEGER NOT NULL, profile TEXT NOT NULL)",
  "CREATE INDEX IF NOT EXISTS df_sessions_by_user ON df_sessions(user_id)",
  "CREATE INDEX IF NOT EXISTS df_sessions_by_expiry ON df_sessions(expires)",
  "CREATE TABLE IF NOT EXISTS df_auth_attempts (bucket TEXT PRIMARY KEY, hits INTEGER NOT NULL, expires INTEGER NOT NULL)",
  "CREATE INDEX IF NOT EXISTS df_auth_attempts_by_expiry ON df_auth_attempts(expires)",
  "CREATE TABLE IF NOT EXISTS df_tournament_access (tournament_id TEXT PRIMARY KEY, salt TEXT NOT NULL, password_hash TEXT NOT NULL)",
  "CREATE TABLE IF NOT EXISTS df_referee_grants (tournament_id TEXT NOT NULL, user_id TEXT NOT NULL, PRIMARY KEY (tournament_id, user_id))",
  "CREATE TABLE IF NOT EXISTS df_match_referees (tournament_id TEXT NOT NULL, fixture_id TEXT NOT NULL, user_id TEXT NOT NULL, PRIMARY KEY (tournament_id, fixture_id, user_id))",
  "CREATE TABLE IF NOT EXISTS df_resume_states (match_id TEXT PRIMARY KEY, state TEXT NOT NULL)"
];

const initializedSchemas = new WeakMap();

function ensureSchema(db) {
  if (!initializedSchemas.has(db)) {
    const initialization = db.prepare("SELECT name FROM sqlite_master WHERE name = 'df_match_referees'")
      .first().then(marker => marker || db.batch(DB_SCHEMA.map(sql => db.prepare(sql))))
      .catch(error => {
        initializedSchemas.delete(db);
        throw error;
      });
    initializedSchemas.set(db, initialization);
  }
  return initializedSchemas.get(db);
}

const utf8 = new TextEncoder();
const googleClientIdPattern = /^[\w-]+\.apps\.googleusercontent\.com$/;
const passwordIterations = 100000;
const sessionLifetime = 7 * 86400;
const sessionCookieName = "df_session_v2";
const googlePublicKeysUrl = "https://www.googleapis.com/oauth2/v3/certs";
let googleKeys = { keys: [], expires: 0 };

function base64Url(bytes) {
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromBase64Url(value) {
  return Uint8Array.from(atob(value.replace(/-/g, "+").replace(/_/g, "/")), char => char.charCodeAt(0));
}

function randomToken(size) {
  return base64Url(crypto.getRandomValues(new Uint8Array(size)));
}

async function digest(value) {
  return base64Url(new Uint8Array(await crypto.subtle.digest("SHA-256", utf8.encode(value))));
}

function equalValue(left, right) {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index++) difference |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return difference === 0;
}

async function hashPassword(password, salt) {
  const key = await crypto.subtle.importKey("raw", utf8.encode(password), "PBKDF2", false, ["deriveBits"]);
  const hash = await crypto.subtle.deriveBits({
    name: "PBKDF2", hash: "SHA-256", salt: fromBase64Url(salt), iterations: passwordIterations
  }, key, 256);
  return base64Url(new Uint8Array(hash));
}

function googleClientId(env, settings) {
  const clientId = (env.GOOGLE_CLIENT_ID || settings?.google_client_id || "").trim();
  return googleClientIdPattern.test(clientId) ? clientId : "";
}

async function verifyGoogleCredential(credential, audience) {
  if (typeof credential !== "string" || credential.length > 8192) return null;
  const pieces = credential.split(".");
  if (pieces.length !== 3 || pieces.some(piece => !/^[\w-]+$/.test(piece))) return null;

  const [head, payload, signature] = pieces;
  let header, claims;
  try {
    const decoder = new TextDecoder();
    header = JSON.parse(decoder.decode(fromBase64Url(head)));
    claims = JSON.parse(decoder.decode(fromBase64Url(payload)));
  } catch {
    return null;
  }

  const now = Math.floor(Date.now() / 1000);
  if (header?.alg !== "RS256" || typeof header.kid !== "string" || claims?.aud !== audience
    || !["accounts.google.com", "https://accounts.google.com"].includes(claims.iss)
    || !Number.isInteger(claims.exp) || claims.exp <= now
    || !Number.isInteger(claims.iat) || claims.iat > now + 60
    || claims.email_verified !== true || typeof claims.email !== "string"
    || typeof claims.sub !== "string" || !claims.sub || claims.sub.length > 255) return null;

  let jwk = googleKeys.keys.find(key => key.kid === header.kid && key.kty === "RSA");
  if (Date.now() >= googleKeys.expires || !jwk) {
    let lastError;
    for (let attempt = 0; attempt < 2; attempt++) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 10000);
      try {
        const response = await fetch(googlePublicKeysUrl, {
          redirect: "manual", signal: controller.signal, headers: { Accept: "application/json" },
          cf: { cacheTtl: 3600, cacheEverything: true }
        });
        if (!response.ok) throw new Error("Google keys HTTP " + response.status);
        const { keys } = await response.json();
        if (!Array.isArray(keys) || !keys.length) throw new Error("Invalid Google key response");
        const maxAge = Number(response.headers.get("Cache-Control")?.match(/max-age=(\d+)/)?.[1] || 300);
        googleKeys = { keys, expires: Date.now() + Math.min(maxAge, 3600) * 1000 };
        lastError = null;
        break;
      } catch (error) { lastError = error; }
      finally { clearTimeout(timer); }
    }
    if (lastError) throw lastError;
    jwk = googleKeys.keys.find(key => key.kid === header.kid && key.kty === "RSA");
  }
  if (!jwk) return null;
  try {
    const key = await crypto.subtle.importKey("jwk", jwk,
      { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
    const valid = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, fromBase64Url(signature), utf8.encode(head + "." + payload));
    return valid ? claims : null;
  } catch {
    return null;
  }
}

function sessionToken(request) {
  return request.headers.get("Cookie")?.match(/(?:^|;\s*)df_session_v2=([\w-]{43})(?:;|$)/)?.[1];
}

function sessionCookie(value, url) {
  const maxAge = value ? sessionLifetime : 0;
  const secure = url.protocol === "https:" ? "; Secure" : "";
  return `${sessionCookieName}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure}`;
}

async function authenticatedUser(request, db) {
  const token = sessionToken(request);
  if (!token) return null;
  const row = await db.prepare("SELECT profile FROM df_sessions WHERE digest = ? AND expires > ?")
    .bind(await digest(token), Date.now()).first();
  const user = row ? JSON.parse(row.profile) : null;
  return user?.role === 'member' && user.provider !== 'google_oauth' ? null : user;
}

async function startSession(store, user, url, request) {
  const token = randomToken(32);
  const existing = sessionToken(request);
  if (existing) {
    store.statements.push(store.db.prepare("DELETE FROM df_sessions WHERE digest = ?").bind(await digest(existing)));
  }
  const now = Date.now();
  store.statements.push(
    store.db.prepare("DELETE FROM df_sessions WHERE expires <= ?").bind(now),
    store.db.prepare("INSERT INTO df_sessions (digest, user_id, expires, profile) VALUES (?, ?, ?, ?)")
      .bind(await digest(token), user.id, now + sessionLifetime * 1000, JSON.stringify(user))
  );
  return sessionCookie(token, url);
}

async function endSession(request, db, url) {
  const token = sessionToken(request);
  if (token) await db.prepare("DELETE FROM df_sessions WHERE digest = ?").bind(await digest(token)).run();
  return sessionCookie("", url);
}

async function allowAuthAttempt(request, db, kind) {
  const now = Date.now();
  const ip = request.headers.get("CF-Connecting-IP") || "local";
  const bucket = await digest(kind + ":" + ip);
  const maximum = kind === "admin" || kind.startsWith("referee:") ? 8 : 60;
  const [, result] = await db.batch([
    db.prepare("DELETE FROM df_auth_attempts WHERE expires <= ?").bind(now),
    db.prepare(`INSERT INTO df_auth_attempts (bucket, hits, expires) VALUES (?, 1, ?)
      ON CONFLICT (bucket) DO UPDATE SET hits = hits + 1 WHERE hits < ? RETURNING hits`)
      .bind(bucket, now + 5 * 60000, maximum)
  ]);
  return result.results.length > 0;
}


const DEFAULT_PLAYERS = [];

const DEFAULT_SETTINGS = {
  google_sheet_url: "",
  google_client_id: "",
  auto_sync_sheets: true,
  default_match_type: "doubles",
  default_sport: "padel",
  default_sets_to_win: 2,
  default_games_per_set: 6,
  default_tiebreak_at: 6,
  default_golden_point: false,
  sound_enabled: true,
  voice_lang: "id-ID",
  court_name: "Lapangan Utama",
  courts_list: ["Lapangan 1", "Lapangan 2", "Lapangan 3"]
};

const DEFAULT_COURTS = [
  { id: "court_1", name: "Lapangan 1", active_match: null, last_updated: null },
  { id: "court_2", name: "Lapangan 2", active_match: null, last_updated: null },
  { id: "court_3", name: "Lapangan 3", active_match: null, last_updated: null }
];

const STORE_DEFAULTS = {
  settings: DEFAULT_SETTINGS,
  players: DEFAULT_PLAYERS,
  tournaments: [],
  matches: [],
  users: [],
  courts: DEFAULT_COURTS
};

const REVISION_SQL = "SELECT revision, data_revision FROM df_revision WHERE id = 1";

function fixedCourts(courts = []) {
  return DEFAULT_COURTS.map(court => ({
    ...court,
    ...(courts.find(c => c.id === court.id) || {}),
    name: court.name
  }));
}

function publicCourt(court) {
  if (!court.active_match) return court;
  const { history, redoStack, ...match } = court.active_match;
  return {
    ...court,
    active_match: { ...match, undo_count: history?.length || 0, redo_count: redoStack?.length || 0 }
  };
}

function resumableMatch(match) {
  return match.status === 'completed' && Boolean(match.resumable || (match.win_reason === 'Diselesaikan manual' && match.current_points && match.current_set_games));
}

function makeStore(db) {
  return { db, reads: new Map(), writes: new Map(), statements: [], afterCommit: [] };
}

async function readStore(store, key, defaultValue) {
  if (store.writes.has(key)) return store.writes.get(key);
  if (!store.reads.has(key)) {
    store.reads.set(key, store.db.prepare("SELECT value FROM df_state WHERE key = ? ORDER BY part")
      .bind(key).all().then(({ results }) => results.length
        ? JSON.parse(results.map(row => row.value).join(""))
        : structuredClone(defaultValue)));
  }
  return store.reads.get(key);
}

function writeStore(store, key, data) {
  store.writes.set(key, data);
}

async function commitStore(store, revision) {
  const dataChanged = [...store.writes.keys()].some(key => key !== "courts");
  // A failed CHECK rolls back the whole batch when another request committed first.
  const statements = [store.db.prepare(
    "UPDATE df_revision SET revision = CASE WHEN revision = ? THEN revision + 1 ELSE -1 END, data_revision = data_revision + ? WHERE id = 1"
  ).bind(revision, Number(dataChanged))];
  for (const [key, value] of store.writes) {
    statements.push(store.db.prepare("DELETE FROM df_state WHERE key = ?").bind(key));
    const json = JSON.stringify(value);
    // Keep each value below D1's row size limit, including UTF-8 text.
    const chunkSize = 250000;
    for (let offset = 0, part = 0; offset < json.length; part++) {
      let end = Math.min(offset + chunkSize, json.length);
      if (/[\uD800-\uDBFF]/.test(json[end - 1])) end--;
      statements.push(store.db.prepare("INSERT INTO df_state (key, part, value) VALUES (?, ?, ?)")
        .bind(key, part, json.slice(offset, end)));
      offset = end;
    }
  }
  try {
    await store.db.batch([...statements, ...store.statements]);
    return true;
  } catch (error) {
    const current = await store.db.prepare(REVISION_SQL).first();
    if (current?.revision !== revision) return false;
    throw error;
  }
}

async function initializeStore(env) {
  const db = env.DF_SCORING_DB;
  const current = await db.prepare(REVISION_SQL).first();
  if (current.revision !== 0) return;
  const store = makeStore(db);
  const kv = env.DF_SCORING_KV || env.PADEL_DB;
  for (const [key, fallback] of Object.entries(STORE_DEFAULTS)) {
    const previous = key !== "courts" && kv ? await kv.get(key, { type: "json" }) : null;
    writeStore(store, key, previous ?? fallback);
  }
  await commitStore(store, 0);
}

async function snapshot(db, since = null) {
  const statement = since === null
    ? db.prepare("SELECT key, value FROM df_state ORDER BY key, part")
    : db.prepare(`SELECT key, value FROM df_state WHERE key = 'courts'
        AND (SELECT revision FROM df_revision WHERE id = 1) <> ? ORDER BY part`).bind(since);
  const [meta, rows] = await db.batch([db.prepare(REVISION_SQL), statement]);
  if (since === meta.results[0].revision) return meta.results[0];
  const values = {};
  for (const row of rows.results) (values[row.key] ??= []).push(row.value);
  for (const key of Object.keys(values)) values[key] = JSON.parse(values[key].join(""));
  values.courts = fixedCourts(values.courts).map(publicCourt);
  return { ...values, ...meta.results[0] };
}

function scoredBy(user) {
  return { name: user.name, email: user.email, role: user.role };
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store, no-cache, must-revalidate",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization"
    }
  });
}

function arrayBufferToBase64(buffer) {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

function nowFormatted() {
  const d = new Date(Date.now() + 7 * 3600 * 1000); // WIB (UTC+7)
  return d.toISOString().replace("T", " ").substring(0, 19);
}

function shortId() {
  return Math.random().toString(36).substring(2, 10);
}

async function recalculateAllPlayerStats(store) {
  const players = await readStore(store, "players", DEFAULT_PLAYERS);
  const matches = await readStore(store, "matches", []);

  for (const p of players) {
    p.matches_played = 0;
    p.matches_won = 0;
    p.matches_lost = 0;
    p.sets_won = 0;
    p.sets_lost = 0;
    p.games_won = 0;
    p.games_lost = 0;
  }

  for (const m of matches) {
    if (m.status !== "completed" || !m.winner) continue;
    const winner = m.winner;
    const teamAIds = (m.team_a_player_ids || []).concat((m.team_a_players || []).map(x => x && x.id)).filter(Boolean);
    const teamBIds = (m.team_b_player_ids || []).concat((m.team_b_players || []).map(x => x && x.id)).filter(Boolean);
    const teamANames = (m.team_a_players || []).map(x => x && x.name && x.name.toLowerCase()).filter(Boolean);
    const teamBNames = (m.team_b_players || []).map(x => x && x.name && x.name.toLowerCase()).filter(Boolean);

    let setsA = 0, setsB = 0, gamesA = 0, gamesB = 0;
    for (const s of (m.sets_history || [])) {
      const gA = parseInt(s.team_a);
      const gB = parseInt(s.team_b);
      if (!isNaN(gA) && !isNaN(gB)) {
        gamesA += gA;
        gamesB += gB;
        if (!s.partial) {
          if (s.winner === "team_a" || gA > gB) setsA++;
          else if (s.winner === "team_b" || gB > gA) setsB++;
        }
      } else if (s.winner === "team_a") {
        setsA++;
      } else if (s.winner === "team_b") {
        setsB++;
      }
    }

    for (const p of players) {
      const pNameLower = (p.name || "").toLowerCase();
      const inA = teamAIds.includes(p.id) || teamANames.includes(pNameLower) || pNameLower === (m.team_a_name || "").toLowerCase();
      const inB = teamBIds.includes(p.id) || teamBNames.includes(pNameLower) || pNameLower === (m.team_b_name || "").toLowerCase();

      if (inA) {
        p.matches_played++;
        if (winner === "team_a") p.matches_won++;
        else p.matches_lost++;
        p.sets_won = (p.sets_won || 0) + setsA;
        p.sets_lost = (p.sets_lost || 0) + setsB;
        p.games_won = (p.games_won || 0) + gamesA;
        p.games_lost = (p.games_lost || 0) + gamesB;
      } else if (inB) {
        p.matches_played++;
        if (winner === "team_b") p.matches_won++;
        else p.matches_lost++;
        p.sets_won = (p.sets_won || 0) + setsB;
        p.sets_lost = (p.sets_lost || 0) + setsA;
        p.games_won = (p.games_won || 0) + gamesB;
        p.games_lost = (p.games_lost || 0) + gamesA;
      }
    }
  }

  await writeStore(store, "players", players);
  return players;
}

function validMatchStart(match) {
  const rules = match.rules;
  return typeof match.id === "string" && /^m_[a-z0-9-]{8,40}$/.test(match.id)
    && ["padel", "tennis"].includes(match.sport) && ["singles", "doubles"].includes(match.mode)
    && [match.team_a_name, match.team_b_name].every(name => typeof name === "string" && name.trim() && name.length <= 160)
    && Number.isInteger(rules?.games_per_set) && rules.games_per_set >= 1 && rules.games_per_set <= 50
    && [1, 2, 3].includes(rules.sets_to_win)
    && [match.team_a_players, match.team_b_players].every(players => Array.isArray(players)
      && players.length <= 2 && players.every(player => typeof player?.name === "string"));
}

function serializeActive(scorer) {
  return { ...scorer.toLightJSON(), history: scorer.history, redoStack: scorer.redoStack };
}

function sameFixture(active, match) {
  return active && active.tournament_id === match.tournament_id
    && active.tournament_match_id === match.tournament_match_id;
}

async function findTournament(store, id) {
  const tournaments = await readStore(store, "tournaments", []);
  const tournament = tournaments.find(item => item.id === id);
  return tournament ? TournamentManager.normalize(tournament) : null;
}

async function canReferee(store, user, tournamentId, fixtureId) {
  if (user?.role === 'admin') return true;
  if (!user || !tournamentId || !fixtureId) return false;
  return Boolean(await store.db.prepare('SELECT user_id FROM df_match_referees WHERE tournament_id = ? AND fixture_id = ? AND user_id = ?')
    .bind(tournamentId, fixtureId, user.id).first());
}

function refereeDenied() {
  return jsonResponse({ error: 'Hanya admin atau wasit yang memiliki password turnamen dapat mengubah pertandingan.' }, 403);
}

async function canControlMatch(store, user, match) {
  return match.tournament_id ? canReferee(store, user, match.tournament_id, match.tournament_match_id)
    : user?.role === 'admin' || Boolean(user && match.referee_user_id === user.id);
}

// Reopen only the dependent branch; never invalidate a match already played.
function reopenFixture(tournament, fixtureId, courts) {
  const fixture = TournamentManager.findMatch(tournament, fixtureId);
  if (!fixture) return false;
  const chain = [];
  let previous = fixture;
  if (tournament.format === 'knockout') {
    while (true) {
      const next = tournament.rounds.flatMap(round => round.matches).find(match => match.feeds_from?.includes(previous.id));
      if (!next) break;
      if (next.status === 'completed' || courts.some(court => court.active_match?.tournament_id === tournament.id
        && court.active_match.tournament_match_id === next.id)) return false;
      chain.push({ next, previous });
      previous = next;
    }
  }
  for (const { next, previous } of chain) next[next.feeds_from.indexOf(previous.id) === 0 ? 'team_a' : 'team_b'] = null;
  Object.assign(fixture, { status: 'pending', winner: null, winner_participant: null, sets_history: [],
    score_display: 'vs', win_type: null, win_reason: '' });
  Object.assign(tournament, { status: 'active', champion: null, champion_name: null, revision: (tournament.revision || 0) + 1 });
  return true;
}

async function postSheet(url, payload) {
  const destination = new URL(url);
  if (destination.protocol !== "https:" || destination.hostname !== "script.google.com"
    || !destination.pathname.endsWith("/exec") || destination.username || destination.password) {
    throw new Error("Gunakan URL deployment Google Apps Script yang berakhiran /exec.");
  }
  const response = await fetch(destination, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(10000)
  });
  if (!response.ok) throw new Error("Google Apps Script menolak permintaan.");
  const result = await response.json().catch(() => null);
  if (result?.status !== "success") throw new Error("Webhook gagal memproses data. Periksa deployment dan akses Apps Script.");
}

async function recordCompletedMatch(store, match) {
  if (match.tournament_id) {
    const tournaments = await readStore(store, "tournaments", []);
    const tournament = await findTournament(store, match.tournament_id);
    const fixture = TournamentManager.findMatch(tournament, match.tournament_match_id);
    if (!TournamentManager.isPlayable(fixture)) return "Pertandingan turnamen ini sudah selesai atau tidak tersedia.";
    match.tournament_name = tournament.name;
    match.team_a_name = fixture.team_a.name;
    match.team_b_name = fixture.team_b.name;
    if (match.win_type === "walkover" && !match.start_time) {
      match.team_a_players = fixture.team_a.players || [fixture.team_a];
      match.team_b_players = fixture.team_b.players || [fixture.team_b];
      match.win_reason = String(match.win_reason || "Menang W.O.").slice(0, 200);
      match.sets_history = [];
    }
    TournamentManager.recordMatchResult(tournament, fixture.id, match);
    tournament.revision = (tournament.revision || 0) + 1;
    tournaments[tournaments.findIndex(item => item.id === tournament.id)] = tournament;
    writeStore(store, "tournaments", tournaments);
  }

  match.date ||= nowFormatted();
  match.winner_name = match[match.winner + "_name"];
  const matches = await readStore(store, "matches", []);
  matches.unshift(match);
  writeStore(store, "matches", matches);
  await recalculateAllPlayerStats(store);

  const settings = await readStore(store, "settings", DEFAULT_SETTINGS);
  const sheetUrl = settings.google_sheet_url || settings.google_sheet_webhook_url;
  if ((settings.auto_sync_sheets ?? settings.auto_sync_sheet) && sheetUrl) {
    store.afterCommit.push(async () => {
      try {
        await postSheet(sheetUrl, { type: "match", data: match });
      } catch (error) {
        console.error("DF Scoring Sheets sync:", error.name);
      }
    });
  }
  return null;
}

async function signIn(context, action) {
  const { request, env, store, auth } = context;
  const url = new URL(request.url);
  const { kind, body } = auth;
  const courtId = DEFAULT_COURTS.some(court => court.id === body.court_id) ? body.court_id : "court_1";
  const admin = kind === "admin";
  const role = admin ? "admin" : "member";
  const provider = admin ? "admin_password" : "google_oauth";
  let name, email, picture, login, account;

  if (admin) {
    if (!env.DF_ADMIN_PASSWORD) {
      return jsonResponse({ error: "Masuk Admin belum aktif. Simpan secret DF_ADMIN_PASSWORD di pengaturan Production Cloudflare, lalu deploy ulang.", code: "ADMIN_NOT_CONFIGURED" }, 503);
    }
    const supplied = typeof body.password === "string" ? body.password.trim() : "";
    if (!supplied || supplied.length > 128 || !equalValue(await digest(supplied), await digest(env.DF_ADMIN_PASSWORD))) {
      return jsonResponse({ error: "Password Admin salah." }, 401);
    }
    name = typeof body.name === "string" ? body.name.trim().slice(0, 80) : "";
    name ||= "Admin Utama";
    email = "admin@dfscoring.pro";
  } else if (kind === "google") {
    const settings = await readStore(store, "settings", DEFAULT_SETTINGS);
    const clientId = googleClientId(env, settings);
    if (!clientId) return jsonResponse({ error: "Masuk Google belum disiapkan. Hubungi admin untuk mengaktifkan Google Client ID.", code: "GOOGLE_NOT_CONFIGURED" }, 503);
    if (auth.verifiedGoogle?.aud !== clientId) {
      try {
        auth.verifiedGoogle = await verifyGoogleCredential(body.credential, clientId);
      } catch (error) {
        console.error("Google key verification unavailable:", error.name, error.message);
        return jsonResponse({ error: "Verifikasi Google belum berhasil. Silakan coba tombol Google sekali lagi.", code: "GOOGLE_KEYS_UNAVAILABLE" }, 503);
      }
    }
    if (!auth.verifiedGoogle) return jsonResponse({ error: "Sesi Google tidak valid. Pilih akun Google lagi." }, 401);
    const google = auth.verifiedGoogle;
    email = google.email.toLowerCase().slice(0, 254);
    if (!/@(gmail|googlemail)\.com$/.test(email)) return jsonResponse({ error: "Gunakan akun Gmail untuk menjadi member." }, 403);
    name = typeof google.name === "string" ? google.name.trim().slice(0, 80) : "";
    name ||= email.split("@")[0].slice(0, 80);
    picture = typeof google.picture === "string" && /^https:\/\/[\w.-]+\//.test(google.picture)
      ? google.picture.slice(0, 400) : undefined;
    login = "google:" + google.sub;
  } else {
    return jsonResponse({ error: "Member wajib masuk dengan Google/Gmail." }, 403);
  }

  if (kind === "google") {
    account = await store.db.prepare("SELECT * FROM df_accounts WHERE login = ?").bind(login).first();
    if (!account) {
      const password = body.password;
      if (typeof password !== "string" || password.length < 8 || password.length > 128) {
        return jsonResponse({ requires_password: true, message: "Create Password: buat password akun minimal 8 karakter. Login tetap wajib Google." });
      }
      auth.salt ||= randomToken(16);
      auth.passwordHash ||= await hashPassword(password, auth.salt);
    }
  }
  const users = await readStore(store, "users", []);
  const previous = admin ? users.find(user => user.role === "admin" && user.name === name)
    : users.find(user => user.id === account?.user_id && user.role === "member");
  const id = account?.user_id || previous?.id || "u_" + crypto.randomUUID();
  const playerId = typeof body.player_id === "string" ? body.player_id : "";
  const players = playerId ? await readStore(store, "players", DEFAULT_PLAYERS) : [];
  const profile = {
    id, name, email, role, provider, court_id: courtId,
    picture: picture || previous?.picture || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name)}`,
    player_id: players.some(player => player.id === playerId) ? playerId : previous?.player_id || null,
    created_at: previous?.created_at || nowFormatted(),
    last_login: nowFormatted(),
    login_count: (previous?.login_count || 0) + 1
  };
  if (!admin && !account) {
    store.statements.push(store.db.prepare(
      "INSERT INTO df_accounts (login, user_id, name, email, salt, password_hash) VALUES (?, ?, ?, ?, ?, ?)"
    ).bind(login, id, name, email, auth.salt || null, auth.passwordHash || null));
  }
  writeStore(store, "users", [profile, ...users.filter(user => user.id !== id)]);
  const response = jsonResponse({ status: "success", user: profile }, action === "register" ? 201 : 200);
  response.headers.set("Set-Cookie", await startSession(store, profile, url, request));
  return response;
}

async function handleApi(context) {
  const { request, env, store, user } = context;
  const url = new URL(request.url);
  const method = request.method.toUpperCase();

  if (method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      }
    });
  }

  const path = url.pathname.replace(/^\/api\/?/, "").replace(/\/$/, "");
  const segments = path ? path.split("/") : [];

  try {
    if (segments[0] === "auth" && segments[1] === "logout" && method === "POST") {
      const response = jsonResponse({ status: "success" });
      response.headers.set("Set-Cookie", await endSession(request, store.db, url));
      return response;
    }

    if (segments[0] === "auth" && segments[1] === "session" && method === "GET") {
      return jsonResponse({ user });
    }

    if (segments[0] === "bootstrap" && method === "GET") {
      const state = await snapshot(store.db);
      state.matches = state.matches.map(match => ({ ...match, resumable: resumableMatch(match) }));
      if (user?.role !== "admin") {
        state.users = [];
        delete state.settings.google_sheet_url;
        delete state.settings.google_sheet_webhook_url;
      }
      const grants = user ? await store.db.prepare("SELECT tournament_id, fixture_id FROM df_match_referees WHERE user_id = ?").bind(user.id).all() : { results: [] };
      return jsonResponse({
        ...state,
        referee_matches: grants.results,
        settings: { ...DEFAULT_SETTINGS, ...state.settings, google_client_id: googleClientId(env, state.settings) },
        info: {
          app_name: "DF Scoring PRO",
          local_ip: url.host,
          port: 443,
          network_url: url.origin,
          cloud_mode: true
        }
      });
    }

    if (segments[0] === "live" && method === "GET") {
      const since = Number(url.searchParams.get("since") ?? -1);
      return jsonResponse(await snapshot(store.db, Number.isSafeInteger(since) ? since : -1));
    }

    // 1. GET /api/info
    if (segments[0] === "info" && method === "GET") {
      return jsonResponse({
        app_name: "DF Scoring PRO",
        local_ip: url.host,
        port: 443,
        network_url: `${url.protocol}//${url.host}`,
        cloud_mode: true
      });
    }

    if (context.auth) return signIn(context, segments[1]);

    if (method !== "GET" && !user) return jsonResponse({ error: "Silakan masuk kembali." }, 401);
    const adminOnly = ["admin", "users", "settings", "sync-sheets", "test-sheet-connection"].includes(segments[0])
      || (["players", "upload-photo", "upload-audio", "upload"].includes(segments[0]) && method !== "GET")
      || (segments[0] === "tournaments" && method === "DELETE")
      || (segments[0] === "courts" && segments[2] === "clear")
      || (segments[0] === "matches" && ["PUT", "DELETE"].includes(method) && segments.length > 1);
    if (adminOnly && user?.role !== "admin") return jsonResponse({ error: "Akses khusus admin." }, 403);

    if (segments[0] === "users") {
      let users = await readStore(store, "users", []);
      if (segments.length === 1 && method === "GET") {
        return jsonResponse(users);
      }
      if (segments.length === 2 && method === "DELETE") {
        const uid = segments[1];
        users = users.filter(u => u.id !== uid);
        writeStore(store, "users", users);
        store.statements.push(store.db.prepare("DELETE FROM df_sessions WHERE user_id = ?").bind(uid));
        return jsonResponse({ status: "deleted", id: uid });
      }
    }

    // 3. /api/admin/*
    if (segments[0] === "admin") {
      if (segments[1] === "recalculate-stats" && method === "POST") {
        const updatedPlayers = await recalculateAllPlayerStats(store);
        return jsonResponse({ status: "success", players: updatedPlayers });
      }

      if (segments[1] === "backup" && method === "GET") {
        const { revision, data_revision, ...data } = await snapshot(store.db);
        return jsonResponse({ backup_version: "4.0", exported_at: nowFormatted(), ...data });
      }

      if (segments[1] === "restore" && method === "POST") {
        const data = await request.json();
        if (Array.isArray(data.players)) await writeStore(store, "players", data.players);
        if (Array.isArray(data.matches)) await writeStore(store, "matches", data.matches);
        if (Array.isArray(data.tournaments)) await writeStore(store, "tournaments", data.tournaments);
        const courts = await readStore(store, "courts", DEFAULT_COURTS);
        if (courts.some(court => court.active_match)) {
          return jsonResponse({ error: "Selesaikan semua pertandingan aktif sebelum memulihkan database." }, 409);
        }
        if (Array.isArray(data.users)) await writeStore(store, "users", data.users);
        if (data.settings && typeof data.settings === "object") {
          await writeStore(store, "settings", { ...DEFAULT_SETTINGS, ...data.settings });
        }
        return jsonResponse({ status: "success", message: "Database berhasil dipulihkan!" });
      }
    }

    // 4. GET / POST /api/settings
    if (segments[0] === "settings") {
      const current = await readStore(store, "settings", DEFAULT_SETTINGS);
      if (method === "GET") {
        return jsonResponse({ ...DEFAULT_SETTINGS, ...current });
      }
      if (method === "POST") {
        const body = await request.json();
        if (body.google_client_id && (typeof body.google_client_id !== "string" || !googleClientIdPattern.test(body.google_client_id))) {
          return jsonResponse({ error: "OAuth Client ID Google harus berakhiran .apps.googleusercontent.com." }, 400);
        }
        const updated = { ...DEFAULT_SETTINGS, ...current, ...body };
        await writeStore(store, "settings", updated);
        return jsonResponse(updated);
      }
    }

    // 5. /api/players & /api/players/:id
    if (segments[0] === "players") {
      let players = await readStore(store, "players", DEFAULT_PLAYERS);

      if (segments.length === 1 && method === "GET") {
        return jsonResponse(players);
      }

      if (segments.length === 1 && method === "POST") {
        const body = await request.json();
        const newPlayer = {
          id: shortId(),
          name: body.name || "Pemain Baru",
          nickname: body.nickname || "",
          photo_url: body.photo_url || "",
          handedness: body.handedness || "Kanan",
          level: body.level || "Intermediate",
          notes: body.notes || "",
          slogan_text: body.slogan_text || "",
          slogan_audio_url: body.slogan_audio_url || "",
          matches_played: 0,
          matches_won: 0,
          matches_lost: 0,
          sets_won: 0,
          sets_lost: 0,
          games_won: 0,
          games_lost: 0,
          created_at: nowFormatted()
        };
        players.push(newPlayer);
        await writeStore(store, "players", players);
        return jsonResponse(newPlayer);
      }

      if (segments.length === 2) {
        const playerId = segments[1];
        if (method === "PUT") {
          const body = await request.json();
          const idx = players.findIndex(p => p.id === playerId);
          if (idx === -1) return jsonResponse({ error: "Player not found" }, 404);
          players[idx] = { ...players[idx], ...body, id: playerId };
          await writeStore(store, "players", players);
          return jsonResponse(players[idx]);
        }
        if (method === "DELETE") {
          players = players.filter(p => p.id !== playerId);
          await writeStore(store, "players", players);
          return jsonResponse({ status: "deleted", id: playerId });
        }
      }
    }

    // 6. POST /api/upload-photo & /api/upload-audio
    if ((segments[0] === "upload-photo" || segments.join("/") === "upload/photo") && method === "POST") {
      const formData = await request.formData();
      const file = formData.get("file");
      if (!file) return jsonResponse({ error: "No file uploaded" }, 400);
      const buffer = await file.arrayBuffer();
      const base64 = arrayBufferToBase64(buffer);
      const mime = file.type || "image/jpeg";
      const dataUrl = `data:${mime};base64,${base64}`;
      return jsonResponse({ url: dataUrl, filename: file.name || "photo.jpg" });
    }

    if ((segments[0] === "upload-audio" || segments.join("/") === "upload/audio") && method === "POST") {
      const formData = await request.formData();
      const file = formData.get("file");
      if (!file) return jsonResponse({ error: "No audio uploaded" }, 400);
      const buffer = await file.arrayBuffer();
      const base64 = arrayBufferToBase64(buffer);
      const mime = file.type || "audio/webm";
      const dataUrl = `data:${mime};base64,${base64}`;
      return jsonResponse({ url: dataUrl, filename: file.name || "slogan.webm" });
    }

    if (segments[0] === "courts") {
      const courts = fixedCourts(await readStore(store, "courts", DEFAULT_COURTS));
      if (segments.length === 1 && method === "GET") return jsonResponse(courts.map(publicCourt));

      const court = courts.find(c => c.id === segments[1]);
      if (!court) return jsonResponse({ error: "Lapangan tidak tersedia." }, 404);
      if (method !== "POST" || segments.length !== 3) {
        return jsonResponse({ error: "Gunakan alur pertandingan terbaru. Muat ulang halaman." }, 405);
      }

      const body = await request.json();
      const action = segments[2];
      const active = court.active_match;
      const conflict = message => jsonResponse({ error: message, court: publicCourt(court) }, 409);
      let result;
      if (action === "start") {
        if (active) {
          if (active.id === body.id) return jsonResponse({ court: publicCourt(court) });
          return conflict("Lapangan sedang dipakai.");
        }
        if (!validMatchStart(body)) return jsonResponse({ error: "Lengkapi data pertandingan." }, 400);
        const matches = await readStore(store, "matches", []);
        if (matches.some(match => match.id === body.id)) return conflict("Pertandingan ini sudah selesai.");
        if (body.tournament_id || body.tournament_match_id) {
          const tourney = await findTournament(store, body.tournament_id);
          const match = TournamentManager.findMatch(tourney, body.tournament_match_id);
          if (!TournamentManager.isPlayable(match) || courts.some(c => sameFixture(c.active_match, body))) {
            return conflict("Pertandingan turnamen ini sudah dimainkan atau sedang berlangsung.");
          }
          body.team_a_name = match.team_a.name;
          body.team_b_name = match.team_b.name;
          body.team_a_players = match.team_a.players || [match.team_a];
          body.team_b_players = match.team_b.players || [match.team_b];
          body.tournament_name = tourney.name;
          body.sport = tourney.sport || body.sport;
          body.mode = tourney.mode || body.mode;
          body.rules = { ...body.rules, ...tourney.rules, tiebreak_at: tourney.rules?.games_per_set || body.rules.games_per_set };
        }
        const cleanPlayers = players => players.map(player => ({ id: player.id, name: player.name }));
        if (body.tournament_id && !await canReferee(store, user, body.tournament_id, body.tournament_match_id)) return refereeDenied();
        const scorer = new MatchScorer({
          id: body.id, sport: body.sport, mode: body.mode, rules: body.rules,
          team_a_name: body.team_a_name, team_b_name: body.team_b_name,
          team_a_players: cleanPlayers(body.team_a_players), team_b_players: cleanPlayers(body.team_b_players),
          tournament_id: body.tournament_id, tournament_match_id: body.tournament_match_id,
          tournament_name: body.tournament_name, court_id: court.id, scored_by: scoredBy(user)
        });
        court.active_match = { ...serializeActive(scorer), referee_user_id: user.id };
      } else {
        if (active && !await canControlMatch(store, user, active)) return refereeDenied();
        if (action === "finish" && active?.id !== body.match_id) {
          const matches = await readStore(store, "matches", []);
          result = matches.find(match => match.id === body.match_id && match.court_id === court.id);
          if (result) return jsonResponse({ court: publicCourt(court), match: result });
        }
        if (!active || active.id !== body.match_id || active.version !== body.version) {
          return conflict("Skor sudah berubah di perangkat lain. Periksa skor terbaru.");
        }
        if (action === "clear" || action === "cancel") {
          if (active.tournament_id) store.statements.push(store.db.prepare('DELETE FROM df_match_referees WHERE tournament_id = ? AND fixture_id = ?').bind(active.tournament_id, active.tournament_match_id));
          court.active_match = null;
        } else {
          const scorer = MatchScorer.fromJSON(active);
          if (action === "score") {
            if (!scorer.applyAction(body.action)) return jsonResponse({ error: "Aksi skor tidak tersedia." }, 400);
            scorer.scored_by = scoredBy(user);
            court.active_match = { ...serializeActive(scorer), referee_user_id: active.referee_user_id };
          } else if (action === "finish") {
            const resumeState = !scorer.is_completed ? serializeActive(scorer) : null;
            if (!scorer.is_completed && !scorer.finishEarly(body.winner)) {
              return jsonResponse({ error: "Pilih pemenang untuk menyelesaikan pertandingan." }, 400);
            }
            scorer.duration_seconds = Math.max(0, Math.floor(((scorer.end_time || new Date()) - scorer.start_time) / 1000));
            scorer.duration_minutes = Math.max(1, Math.round(scorer.duration_seconds / 60));
            result = { ...scorer.toLightJSON(), status: "completed", scored_by: scoredBy(user) };
            result.referee_user_id = active.referee_user_id;
            result.resumable = Boolean(resumeState);
            if (resumeState) store.statements.push(store.db.prepare("INSERT OR REPLACE INTO df_resume_states (match_id, state) VALUES (?, ?)")
              .bind(result.id, JSON.stringify({ ...resumeState, referee_user_id: active.referee_user_id })));
            const error = await recordCompletedMatch(store, result);
            if (error) return conflict(error);
            if (active.tournament_id) store.statements.push(store.db.prepare('DELETE FROM df_match_referees WHERE tournament_id = ? AND fixture_id = ?').bind(active.tournament_id, active.tournament_match_id));
            court.active_match = null;
          } else {
            return jsonResponse({ error: "Aksi lapangan tidak tersedia." }, 404);
          }
        }
      }

      court.last_updated = nowFormatted();
      writeStore(store, "courts", courts);
      return jsonResponse({ court: publicCourt(court), match: result });
    }

    // 8. /api/matches & /api/matches/:id
    if (segments[0] === "matches") {
      let matches = await readStore(store, "matches", []);

      if (segments.length === 3 && segments[2] === 'resume' && method === 'POST') {
        const previous = matches.find(match => match.id === segments[1]);
        if (!previous) return jsonResponse({ error: 'Riwayat tidak ditemukan atau sudah dilanjutkan.' }, 409);
        if (!await canControlMatch(store, user, previous)) return refereeDenied();
        const saved = await store.db.prepare('SELECT state FROM df_resume_states WHERE match_id = ?').bind(previous.id).first();
        if (!resumableMatch(previous)) return jsonResponse({ error: 'Hanya pertandingan yang diselesaikan manual yang dapat dilanjutkan.' }, 400);
        const body = await request.json();
        const courts = fixedCourts(await readStore(store, 'courts', DEFAULT_COURTS));
        const court = courts.find(item => item.id === body.court_id);
        if (!court || court.active_match) return jsonResponse({ error: 'Pilih lapangan yang masih kosong.' }, 409);
        if (previous.tournament_id) {
          const tournaments = await readStore(store, 'tournaments', []);
          const tournament = await findTournament(store, previous.tournament_id);
          if (!tournament || courts.some(item => sameFixture(item.active_match, previous))
            || !reopenFixture(tournament, previous.tournament_match_id, courts)) {
            return jsonResponse({ error: 'Babak lanjutan sudah dimainkan. Pertandingan ini tidak dapat dibuka kembali.' }, 409);
          }
          writeStore(store, 'tournaments', tournaments.map(item => item.id === tournament.id ? tournament : item));
        }
        // Older manual results already contain the points and service state.
        const state = saved ? JSON.parse(saved.state) : {
          ...previous, status: 'active', is_completed: false, winner: null, end_time: null,
          win_reason: '', win_type: null, sets_history: (previous.sets_history || []).filter(set => !set.partial), history: [], redoStack: []
        };
        delete state.resumable;
        const elapsed = (previous.duration_seconds || 0) * 1000;
        court.active_match = { ...state, court_id: court.id, version: Math.max(previous.version || 1, state.version || 1) + 1,
          start_time: new Date(Date.now() - elapsed).toISOString() };
        court.last_updated = nowFormatted();
        writeStore(store, 'courts', courts);
        writeStore(store, 'matches', matches.filter(match => match.id !== previous.id));
        store.statements.push(store.db.prepare('DELETE FROM df_resume_states WHERE match_id = ?').bind(previous.id));
        await recalculateAllPlayerStats(store);
        return jsonResponse({ court: publicCourt(court) });
      }

      if (segments.length === 1 && method === "GET") {
        return jsonResponse(matches);
      }

      // Direct walkover from a bracket, without claiming an empty court.
      if (segments.length === 1 && method === "POST") {
        const match = await request.json();
        if (!match.tournament_id || !match.tournament_match_id || match.win_type !== "walkover"
          || !["team_a", "team_b"].includes(match.winner)) {
          return jsonResponse({ error: "Selesaikan pertandingan aktif dari papan skor." }, 400);
        }
        if (!await canReferee(store, user, match.tournament_id, match.tournament_match_id)) return refereeDenied();
        const courts = await readStore(store, "courts", DEFAULT_COURTS);
        if (courts.some(c => sameFixture(c.active_match, match))) {
          return jsonResponse({ error: "Selesaikan pertandingan ini dari papan skor lapangan." }, 409);
        }
        const result = {
          id: shortId(), tournament_id: match.tournament_id, tournament_match_id: match.tournament_match_id,
          sport: match.sport, mode: match.mode, court_id: match.court_id,
          winner: match.winner, win_type: "walkover", win_reason: match.win_reason,
          status: "completed", scored_by: scoredBy(user), duration_minutes: 0
        };
        const error = await recordCompletedMatch(store, result);
        if (error) return jsonResponse({ error }, 409);
        return jsonResponse({ status: "success", match: result });
      }

      if (segments.length === 2 && ["PUT", "DELETE"].includes(method)) {
        const matchId = segments[1];
        const idx = matches.findIndex(m => m.id === matchId);
        if (idx === -1) return jsonResponse({ error: "Pertandingan tidak ditemukan." }, 404);
        const previous = matches[idx];
        const tournament = previous.status !== "replayed" && previous.tournament_id && await findTournament(store, previous.tournament_id);
        if (method === "PUT") {
          if (previous.status === "replayed") return jsonResponse({ error: "Hasil lama yang sudah diulang disimpan sebagai arsip. Koreksi hasil pertandingan terbaru." }, 409);
          const body = await request.json();
          const updated = { ...previous, ...body, id: matchId };
          if (tournament) {
            if (updated.winner !== previous.winner) {
              return jsonResponse({ error: "Pemenang turnamen sudah dipakai di bagan." }, 409);
            }
            const fixture = TournamentManager.findMatch(tournament, previous.tournament_match_id);
            if (fixture) {
              fixture.status = "pending";
              TournamentManager.recordMatchResult(tournament, fixture.id, updated);
              tournament.revision = (tournament.revision || 0) + 1;
              const tournaments = await readStore(store, "tournaments", []);
              writeStore(store, "tournaments", tournaments.map(item => item.id === tournament.id ? tournament : item));
            }
          }
          matches[idx] = updated;
          writeStore(store, "matches", matches);
          await recalculateAllPlayerStats(store);
          return jsonResponse({ status: "updated", match: updated });
        }
        if (tournament) return jsonResponse({ error: "Hasil ini masih dipakai di bagan turnamen." }, 409);
        matches = matches.filter(m => m.id !== matchId);
        writeStore(store, "matches", matches);
        await recalculateAllPlayerStats(store);
        return jsonResponse({ status: "deleted", id: matchId });
      }
    }

    // 9. /api/tournaments & /api/tournaments/:id
    if (segments[0] === "tournaments") {
      let tournaments = await readStore(store, "tournaments", []);

      if (segments.length === 3 && ['unlock', 'password', 'replay'].includes(segments[2]) && method === 'POST') {
        const tournament = tournaments.find(item => item.id === segments[1]);
        if (!tournament) return jsonResponse({ error: 'Turnamen tidak ditemukan.' }, 404);
        if (!await allowAuthAttempt(request, store.db, 'referee:' + user.id)) return jsonResponse({ error: 'Terlalu banyak percobaan. Tunggu 5 menit.' }, 429);
        const body = await request.json();
        if (typeof body.password !== 'string' || body.password.length < 8 || body.password.length > 128) {
          return jsonResponse({ error: 'Password turnamen minimal 8 karakter.' }, 400);
        }
        if (segments[2] === 'password') {
          if (user.role !== 'admin') return refereeDenied();
          const salt = randomToken(16);
          store.statements.push(store.db.prepare('INSERT OR REPLACE INTO df_tournament_access VALUES (?, ?, ?)')
            .bind(tournament.id, salt, await hashPassword(body.password, salt)),
            store.db.prepare('DELETE FROM df_match_referees WHERE tournament_id = ?').bind(tournament.id));
          tournament.password_protected = true;
          writeStore(store, 'tournaments', tournaments);
          return jsonResponse({ status: 'success' });
        }
        const secret = await store.db.prepare('SELECT salt, password_hash FROM df_tournament_access WHERE tournament_id = ?').bind(tournament.id).first();
        if (!secret) return jsonResponse({ error: 'Admin perlu mengatur password untuk turnamen lama ini.' }, 409);
        if (!equalValue(await hashPassword(body.password, secret.salt), secret.password_hash)) {
          return jsonResponse({ error: 'Password turnamen salah.' }, 403);
        }
        const fixture = TournamentManager.findMatch(TournamentManager.normalize(tournament), body.fixture_id);
        if (!fixture || fixture.team_a?.is_bye || fixture.team_b?.is_bye) return jsonResponse({ error: 'Pilih match yang ingin Anda wasiti.' }, 400);
        if (segments[2] === 'replay') {
          const current = TournamentManager.normalize(tournament);
          const courts = fixedCourts(await readStore(store, 'courts', DEFAULT_COURTS));
          const court = courts.find(item => item.id === body.court_id);
          if (!court || court.active_match || courts.some(item => sameFixture(item.active_match, { tournament_id: tournament.id, tournament_match_id: fixture.id }))) {
            return jsonResponse({ error: 'Pilih lapangan kosong. Match ini mungkin sudah dimainkan ulang.' }, 409);
          }
          if (fixture.status !== 'completed' || !reopenFixture(current, fixture.id, courts)) {
            return jsonResponse({ error: 'Match tidak dapat diulang karena babak berikutnya sudah dimainkan atau match belum selesai.' }, 409);
          }
          const scorer = new MatchScorer({
            id: 'm_' + crypto.randomUUID(), sport: current.sport, mode: current.mode,
            rules: { ...current.rules, tiebreak_at: current.rules?.games_per_set || 6 },
            team_a_name: fixture.team_a.name, team_b_name: fixture.team_b.name,
            team_a_players: fixture.team_a.players || [fixture.team_a], team_b_players: fixture.team_b.players || [fixture.team_b],
            tournament_id: current.id, tournament_match_id: fixture.id, tournament_name: current.name,
            court_id: court.id, scored_by: scoredBy(user)
          });
          court.active_match = { ...serializeActive(scorer), referee_user_id: user.id };
          court.last_updated = nowFormatted();
          writeStore(store, 'courts', courts);
          writeStore(store, 'tournaments', tournaments.map(item => item.id === current.id ? current : item));
          const matches = await readStore(store, 'matches', []);
          writeStore(store, 'matches', matches.map(match => match.tournament_id === current.id && match.tournament_match_id === fixture.id
            && match.status === 'completed' ? { ...match, status: 'replayed', resumable: false } : match));
          await recalculateAllPlayerStats(store);
          store.statements.push(store.db.prepare('DELETE FROM df_match_referees WHERE tournament_id = ? AND fixture_id = ?').bind(current.id, fixture.id),
            store.db.prepare('INSERT INTO df_match_referees VALUES (?, ?, ?)').bind(current.id, fixture.id, user.id));
          return jsonResponse({ status: 'success', court: publicCourt(court) });
        }
        store.statements.push(store.db.prepare('INSERT OR IGNORE INTO df_match_referees VALUES (?, ?, ?)').bind(tournament.id, fixture.id, user.id));
        return jsonResponse({ status: 'success', tournament_id: tournament.id, fixture_id: fixture.id });
      }

      if (segments.length === 1 && method === "GET") {
        return jsonResponse(tournaments);
      }

      if (segments.length === 1 && method === "POST") {
        const tourney = await request.json();
        if (!tourney.name || !Array.isArray(tourney.participants) || tourney.participants.length < 2
          || !Array.isArray(tourney.rounds) || !tourney.rounds.length) {
          return jsonResponse({ error: "Bagan atau jadwal turnamen belum lengkap." }, 400);
        }
        const password = tourney.password;
        if (typeof password !== "string" || password.length < 8 || password.length > 128) {
          return jsonResponse({ error: "Create Password turnamen minimal 8 karakter." }, 400);
        }
        delete tourney.password;
        delete tourney.password_hash;
        delete tourney.salt;
        tourney.created_by = user.id;
        tourney.password_protected = true;
        tourney.revision = 1;
        tourney.id = "tourn_" + shortId();
        tourney.created_at = tourney.created_at || nowFormatted();
        const salt = randomToken(16);
        store.statements.push(store.db.prepare("INSERT INTO df_tournament_access VALUES (?, ?, ?)")
          .bind(tourney.id, salt, await hashPassword(password, salt)));
        tournaments.unshift(tourney);
        await writeStore(store, "tournaments", tournaments);
        return jsonResponse(tourney);
      }

      if (segments.length === 2) {
        const tournId = segments[1];
        const idx = tournaments.findIndex(t => t.id === tournId);
        if (idx === -1) return jsonResponse({ error: "Turnamen tidak ditemukan." }, 404);
        const courts = await readStore(store, "courts", DEFAULT_COURTS);
        if (method !== "DELETE" && courts.some(court => court.active_match?.tournament_id === tournId)) {
          return jsonResponse({ error: "Selesaikan pertandingan aktif turnamen ini terlebih dahulu." }, 409);
        }
        if (method === "PUT") {
          if (user.role !== "admin") return refereeDenied();
          const data = await request.json();
          const current = tournaments[idx];
          if ((data.revision || 0) !== (current.revision || 0) || TournamentManager.hasResults(current)) {
            return jsonResponse({ error: "Bagan telah berubah atau sudah memiliki hasil pertandingan." }, 409);
          }
          delete data.password;
          tournaments[idx] = { ...data, created_by: current.created_by, password_protected: current.password_protected,
            id: tournId, revision: (current.revision || 0) + 1 };
          await writeStore(store, "tournaments", tournaments);
          return jsonResponse({ status: "updated", tournament: tournaments[idx] });
        }
        if (method === "DELETE") {
          for (const court of courts) if (court.active_match?.tournament_id === tournId) {
            court.active_match = null;
            court.last_updated = nowFormatted();
          }
          writeStore(store, "courts", courts);
          const matches = await readStore(store, "matches", []);
          // Keep history and statistics; detach it from the deleted bracket.
          writeStore(store, "matches", matches.map(match => match.tournament_id === tournId
            ? { ...match, tournament_id: null, tournament_match_id: null } : match));
          store.statements.push(store.db.prepare("DELETE FROM df_tournament_access WHERE tournament_id = ?").bind(tournId),
            store.db.prepare("DELETE FROM df_match_referees WHERE tournament_id = ?").bind(tournId));
          tournaments = tournaments.filter(t => t.id !== tournId);
          await writeStore(store, "tournaments", tournaments);
          return jsonResponse({ status: "deleted", id: tournId });
        }
      }
    }

    // 10. Google Sheet Sync & Test
    if (segments[0] === "sync-sheets" && method === "POST") {
      const settings = await readStore(store, "settings", DEFAULT_SETTINGS);
      const sheetUrl = settings.google_sheet_url || settings.google_sheet_webhook_url;
      if (!sheetUrl) return jsonResponse({ error: "URL Google Sheet belum diatur." }, 400);
      const data = await snapshot(store.db);
      try {
        await postSheet(sheetUrl, {
          type: "bulk_sync", matches: data.matches, players: data.players, tournaments: data.tournaments
        });
        return jsonResponse({ status: "success", synced_count: data.matches.length });
      } catch (error) {
        return jsonResponse({ error: error.message }, 502);
      }
    }

    if (segments[0] === "test-sheet-connection" && method === "POST") {
      const body = await request.json();
      if (!body.google_sheet_url) return jsonResponse({ error: "URL Google Apps Script masih kosong." }, 400);
      try {
        await postSheet(body.google_sheet_url, { type: "ping", timestamp: nowFormatted() });
        return jsonResponse({ status: "success" });
      } catch (error) {
        return jsonResponse({ error: error.message }, 502);
      }
    }

    // 11. Export CSV / Excel fallback on Edge
    if (segments[0] === "export") {
      const matches = await readStore(store, "matches", []);
      const headers = [
        "ID Pertandingan",
        "Tanggal",
        "Olahraga",
        "Mode",
        "Tim / Pemain A",
        "Tim / Pemain B",
        "Skor Set",
        "Pemenang",
        "Status Menang",
        "Turnamen",
        "Lapangan",
        "Dicatat Oleh",
        "Durasi (Menit)"
      ];
      const rows = matches.map(m => {
        const setsScores = (m.sets_history || []).map(s => `${s.team_a}-${s.team_b}`).join(" | ");
        const winnerName = m.winner === "team_a" ? m.team_a_name : m.winner === "team_b" ? m.team_b_name : "-";
        return [
          m.id || "",
          m.date || "",
          (m.sport || "padel").toUpperCase(),
          (m.mode || "doubles").toUpperCase(),
          m.team_a_name || "",
          m.team_b_name || "",
          setsScores,
          winnerName,
          m.win_reason || "Normal (Skor)",
          m.tournament_name || "Friendly Match",
          m.court_id || "court_1",
          m.scored_by?.name || "-",
          m.duration_minutes || 0
        ]
          .map(val => `"${String(val).replace(/"/g, '""')}"`)
          .join(",");
      });
      const csvContent = "\uFEFF" + headers.join(",") + "\n" + rows.join("\n");
      return new Response(csvContent, {
        status: 200,
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": 'attachment; filename="DF_Scoring_Rekap.csv"'
        }
      });
    }

    return jsonResponse({ error: "Endpoint not found", path }, 404);
  } catch (err) {
    if (err instanceof SyntaxError) return jsonResponse({ error: "Data permintaan tidak valid." }, 400);
    throw err;
  }
}

export async function onRequest({ request, env, waitUntil }) {
  const db = env.DF_SCORING_DB;
  if (!db) {
    return jsonResponse({
      error: "Database bersama belum terhubung. Pasang binding D1 DF_SCORING_DB di Production Cloudflare, lalu deploy ulang.",
      code: "DATABASE_NOT_BOUND"
    }, 503);
  }

  try {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin");
    if (origin && request.method !== "GET" && request.method !== "OPTIONS" && origin !== url.origin) {
      return jsonResponse({ error: "Buka aplikasi dari domain DF Scoring untuk melanjutkan." }, 403);
    }
    await ensureSchema(db);
    await initializeStore(env);

    const authAction = url.pathname.match(/^\/api\/auth\/(login|register|google)\/?$/)?.[1];
    let auth;
    if (request.method === "POST" && authAction) {
      if (!request.headers.get("Content-Type")?.toLowerCase().startsWith("application/json")) {
        return jsonResponse({ error: "Format permintaan login tidak valid." }, 415);
      }
      let body;
      try { body = await request.clone().json(); } catch {
        return jsonResponse({ error: "Data formulir login tidak valid." }, 400);
      }
      if (!body || typeof body !== "object" || Array.isArray(body)) {
        return jsonResponse({ error: "Data formulir login tidak valid." }, 400);
      }
      const kind = authAction === "google" ? "google" : authAction === "login" && body.role === "admin" ? "admin" : "email";
      if (!await allowAuthAttempt(request, db, kind)) {
        return jsonResponse({ error: "Terlalu banyak percobaan. Tunggu 5 menit dan coba lagi." }, 429);
      }
      auth = { kind, body };
    }
    const publicRead = request.method === "GET" && ["/api/live", "/api/courts", "/api/info"].includes(url.pathname);
    const user = publicRead || auth ? null : await authenticatedUser(request, db);
    const readOnly = ["GET", "OPTIONS"].includes(request.method);
    for (let attempt = 0; attempt < 6; attempt++) {
      const store = makeStore(db);
      const meta = readOnly ? null : await db.prepare(REVISION_SQL).first();
      const response = await handleApi({ request: readOnly ? request : request.clone(), env, store, user, auth });
      if (!response.ok || (!store.writes.size && !store.statements.length)) {
        if (meta) response.headers.set("X-DF-Revision", String(meta.revision));
        return response;
      }
      if (await commitStore(store, meta.revision)) {
        response.headers.set("X-DF-Revision", String(meta.revision + 1));
        for (const task of store.afterCommit) {
          const work = task();
          if (waitUntil) waitUntil(work);
          else await work;
        }
        return response;
      }
    }
    return jsonResponse({ error: "Database sedang sibuk. Coba lagi." }, 409);
  } catch (error) {
    console.error("DF Scoring database:", error.message);
    return jsonResponse({ error: "Database bersama belum tersedia. Periksa binding dan schema D1." }, 503);
  }
}

export default {
  async fetch(request, env, ctx) {
    const { pathname } = new URL(request.url);
    if (pathname === "/api" || pathname.startsWith("/api/")) {
      return onRequest({ request, env, waitUntil: ctx?.waitUntil.bind(ctx) });
    }
    return env.ASSETS.fetch(request);
  }
};
